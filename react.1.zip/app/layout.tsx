
import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import PageWrapper from './page-wrapper';
import { FirebaseClientProvider } from '@/firebase';
import { AuthGuard } from '@/firebase/auth/auth-guard';


export const metadata: Metadata = {
  title: 'CitySphere',
  description: 'A smart city web application designed to make urban life easier, safer, and more efficient.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
       <head>
       </head>
      <body>
        <FirebaseClientProvider>
          <PageWrapper>
            <AuthGuard>
              {children}
            </AuthGuard>
          </PageWrapper>
        </FirebaseClientProvider>
        <Toaster />
      </body>
    </html>
  );
}
