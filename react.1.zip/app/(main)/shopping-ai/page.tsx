
'use client';

import { useState } from 'react';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Search, ShoppingBag, Store } from 'lucide-react';
import Link from 'next/link';

const aiSuggestions: Record<string, { items: string[], shops: { name: string, link: string }[] }> = {
  // ---------- Kitchen ----------
  kitchen: {
    items: [
      "Gas Stove",
      "Cookware Set",
      "Mixer Grinder",
      "Refrigerator",
      "Water Purifier",
    ],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
      { name: "Croma", link: "https://www.croma.com" },
    ],
  },

  // ---------- Computers ----------
  computer: {
    items: ["Laptop", "Mouse", "Keyboard", "Monitor", "UPS", "WiFi Router"],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Reliance Digital", link: "https://www.reliancedigital.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
    ],
  },
  
  // ---------- Common Needs ----------
   birthday: {
    items: ["Cake", "Greeting Card", "Gift Box", "Flowers", "Decorations"],
    shops: [
      { name: "Archies", link: "https://www.archiesonline.com" },
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
    ],
  },
  college: {
    items: ["College Bag", "Notebook Set", "Water Bottle", "Shoes", "T-Shirts"],
    shops: [
      { name: "Myntra", link: "https://www.myntra.com" },
      { name: "Ajio", link: "https://www.ajio.com" },
      { name: "Amazon", link: "https://www.amazon.in" },
    ],
  },
  travel: {
    items: [
      "Travel Bag",
      "Power Bank",
      "Shoes",
      "Toiletries Kit",
      "Travel Pillow",
    ],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Decathlon", link: "https://www.decathlon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
    ],
  },

  // ---------- Festivals ----------
  diwali: {
    items: [
      "Diyas & Candles",
      "Fairy Lights",
      "Sweets & Dry Fruits",
      "Traditional Dress",
      "Gift Boxes",
      "Home Decorations",
    ],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
      { name: "Reliance Trends", link: "https://www.reliancetrends.com" },
    ],
  },
  christmas: {
    items: [
      "Christmas Tree",
      "Decorative Lights",
      "Santa Cap",
      "Gifts & Toys",
      "Cake & Cookies",
      "Greeting Cards",
    ],
    shops: [
      { name: "Archies", link: "https://www.archiesonline.com" },
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
    ],
  },
  holi: {
    items: [
      "Organic Colors (Gulal)",
      "Water Guns (Pichkari)",
      "White T-shirts",
      "Sweets (Gujiya)",
      "Speakers for Music",
    ],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "D Mart", link: "https://www.dmart.in" },
    ],
  },
  sankranti: {
    items: [
      "Kites & Manja",
      "Tilgul Sweets",
      "New Traditional Dress",
      "Oil & Snacks",
      "Decorative Rangoli Items",
    ],
    shops: [
      { name: "Reliance Smart", link: "https://www.reliancesmart.in" },
      { name: "Amazon", link: "https://www.amazon.in" },
    ],
  },
  eid: {
    items: [
      "Traditional Dress (Kurta, Hijab)",
      "Sewaiyaan & Dry Fruits",
      "Perfume (Attar)",
      "Gift Hampers",
      "Prayer Mat",
    ],
    shops: [
      { name: "Myntra", link: "https://www.myntra.com" },
      { name: "Amazon", link: "https://www.amazon.in" },
    ],
  },
  ganeshchaturthi: {
    items: [
      "Ganesh Idol (Eco-Friendly)",
      "Flowers & Garlands",
      "Clay Lamps",
      "Modak & Prasad",
      "Decorative Items",
    ],
    shops: [
      { name: "Local Craft Stores", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
    ],
  },
  festival: {
    items: [
      "Lights & Decorations",
      "Traditional Outfits",
      "Sweets & Snacks",
      "Gift Hampers",
      "Flowers & Rangoli Items",
    ],
    shops: [
      { name: "Amazon", link: "https://www.amazon.in" },
      { name: "Flipkart", link: "https://www.flipkart.com" },
      { name: "D Mart", link: "https://www.dmart.in" },
    ],
  },
};

type SuggestionResult = {
  items: string[];
  shops: { name: string; link: string }[];
} | null;


export default function ShoppingAiPage() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<SuggestionResult>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = () => {
    setSearched(true);
    const key = query.toLowerCase().trim().replace(/\s/g, ''); // Make it a single word
    if (!key) {
        setResult(null);
        return;
    }
    
    let matched = null;

    // Check for exact match first
    if (aiSuggestions[key]) {
      matched = aiSuggestions[key];
    } else {
      // Try to find partial match (e.g., "diwali items" -> "diwali")
      for (let k in aiSuggestions) {
        if (key.includes(k)) {
          matched = aiSuggestions[k];
          break;
        }
      }
    }
    setResult(matched);
  };

  return (
    <div className="container py-8">
      <PageHeader
        title="AI Shopping Assistant"
        description="Type any festival name or category to get required items and where to buy them."
      />
      <div className="max-w-2xl mx-auto space-y-8">
        <Card>
            <CardHeader>
                <CardTitle>Find Shopping Suggestions</CardTitle>
                <CardDescription>
                  Enter a keyword like &quot;Diwali&quot;, &quot;Christmas&quot;, &quot;kitchen&quot;, or &quot;computer&quot;.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex w-full items-center space-x-2">
                    <Input
                        type="text"
                        placeholder="e.g., Diwali, Christmas, Holi..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                    <Button onClick={handleSearch}>
                        <Search className="mr-2 h-4 w-4" /> Search
                    </Button>
                </div>
            </CardContent>
        </Card>

        {searched && (
            <div>
                {result ? (
                    <div className="grid md:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <ShoppingBag className="h-5 w-5"/> Suggested Items
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                                    {result.items.map((item, i) => (
                                        <li key={i}>{item}</li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Store className="h-5 w-5"/> Recommended Shops
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2">
                                    {result.shops.map((shop, i) => (
                                    <li key={i}>
                                        <Button variant="link" asChild className="p-0 h-auto">
                                            <Link href={shop.link} target="_blank" rel="noopener noreferrer">
                                                {shop.name}
                                            </Link>
                                        </Button>
                                    </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    </div>
                ) : (
                    <Alert>
                        <Search className="h-4 w-4" />
                        <AlertTitle>No Suggestions Found</AlertTitle>
                        <AlertDescription>
                           Sorry, no match found for that festival or category. Try searching for Diwali, Holi, Christmas, Eid, Sankranti, Ganesh Chaturthi, kitchen, or computer.
                        </AlertDescription>
                    </Alert>
                )}
            </div>
        )}
      </div>
    </div>
  );
}
