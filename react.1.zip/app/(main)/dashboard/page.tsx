
'use client';

import Image from 'next/image';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { placeholderImages } from '@/lib/placeholder-images.json';
import type { ImagePlaceholder } from '@/lib/types';
import { ArrowRight, Bot, GitCompareArrows, Map, Mountain, ShieldAlert, ShoppingCart, Wrench, IndianRupee } from 'lucide-react';
import { MotionDiv } from '@/components/shared/motion-div';
import Link from 'next/link';
import { useUser, useUserProfile } from '@/hooks/use-user';
import { Button } from '@/components/ui/button';
import dynamic from 'next/dynamic';

const DashboardCarousel = dynamic(() => import('./dashboard-carousel').then(mod => mod.DashboardCarousel), {
  ssr: false,
  loading: () => <div className="relative w-full h-[60vh] bg-secondary animate-pulse" />
});


const findImage = (id: string): ImagePlaceholder => {
  const image = placeholderImages.find((img) => img.id === id);
  if (!image) throw new Error(`Image with id "${id}" not found.`);
  return image;
};

const carouselImages: ImagePlaceholder[] = [
  findImage('home-carousel-1'),
  findImage('home-carousel-2'),
  findImage('home-carousel-3'),
  findImage('home-tourism'),
];

const featureCards = [
    {
        href: "/traffic",
        icon: <Map className="h-10 w-10 text-primary mb-4" />,
        title: "Live Traffic Updates",
        description: "Navigate your city with ease using our interactive maps with real-time traffic conditions."
    },
    {
        href: "/shopping-ai",
        icon: <Bot className="h-10 w-10 text-primary mb-4" />,
        title: "Shopping AI",
        description: "Chat with our AI to discover affordable shopping locations and get the best value for your money."
    },
    {
        href: "/tourist-assistance",
        icon: <Mountain className="h-10 w-10 text-primary mb-4" />,
        title: "Tourist Assistance",
        description: "Find the best tourist spots, attractions, and hidden gems in your city."
    }
];

const quickActions = [
    { href: "/issue-reporting", icon: <ShieldAlert className="h-8 w-8 text-primary" />, label: "Report an Issue" },
    { href: "/all-in-one-booking", icon: <GitCompareArrows className="h-8 w-8 text-primary" />, label: "Compare Prices" },
    { href: "/budget-shopping", icon: <IndianRupee className="h-8 w-8 text-primary" />, label: "Budget Shopping" },
    { href: "/other-services", icon: <Wrench className="h-8 w-8 text-primary" />, label: "Other Services" },
];

const variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};


export default function DashboardPage() {
  const { user } = useUser();
  const { userProfile } = useUserProfile(user?.uid);

  return (
    <>
       <DashboardCarousel images={carouselImages} />

      <div className="container pt-12 text-center">
         <PageHeader
            title={`Welcome, ${userProfile?.name?.split(' ')[0] || 'Citizen'}!`}
            description="Your smart portal to a more connected and efficient urban life. Get real-time updates, find the best deals, report issues, and explore your city like never before."
            className="text-center"
          />
      </div>

       
        <section className="container py-12">
            <h2 className="text-3xl font-bold text-center mb-12">Quick Actions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {quickActions.map((action, i) => (
                    <MotionDiv key={action.href} variants={variants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.5 }} transition={{ delay: i * 0.1 }}>
                        <Link href={action.href} className="h-full flex">
                            <Card className="w-full flex flex-col items-center justify-center p-6 text-center transition-all duration-300 hover:bg-accent hover:scale-105 hover:shadow-lg">
                            {action.icon}
                            <CardTitle className="mt-4 text-lg">{action.label}</CardTitle>
                            </Card>
                        </Link>
                    </MotionDiv>
                ))}
            </div>
        </section>
       

      <section className="bg-muted/50 dark:bg-card">
        <div className="container py-16">
            <h2 className="text-3xl font-bold text-center mb-12">Explore Core Features</h2>
            <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8">
              {featureCards.map((feature, i) => (
                <MotionDiv key={feature.href} variants={variants} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.5 }} transition={{ delay: 0.1 + i * 0.1 }}>
                    <Link href={feature.href} className="h-full flex">
                        <FeatureCard
                            icon={feature.icon}
                            title={feature.title}
                            description={feature.description}
                        />
                    </Link>
              </MotionDiv>
              ))}
            </div>
        </div>
      </section>
    </>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 h-full flex flex-col w-full group text-center items-center">
      <CardHeader className="p-6">
        {icon}
        <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0 flex-grow">
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button variant="link" className="group-hover:text-primary">
            Explore Feature <ArrowRight className="ml-2 h-4 w-4 transform transition-transform group-hover:translate-x-1" />
        </Button>
      </CardFooter>
    </Card>
  )
}
