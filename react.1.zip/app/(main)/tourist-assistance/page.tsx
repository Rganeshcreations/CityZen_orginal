
'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { PageHeader } from '@/components/shared/page-header';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Ticket, Search, MapPin, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import type { ImagePlaceholder } from '@/lib/types';

interface Place {
  name: string;
  lat: number;
  lng: number;
  opening: string;
  price: string;
  history: string;
  image: ImagePlaceholder;
  mapUrl?: string;
  directionsUrl?: string;
}

export default function TouristAssistancePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Place[]>([]);
  const [searchedCity, setSearchedCity] = useState('');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // This code now runs only on the client, after the component has mounted.
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => setUserLocation({ lat: position.coords.latitude, lng: position.coords.longitude }),
        (error) => console.error("Error getting user location:", error)
      );
    }
  }, []);

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setSearchedCity('');
      return;
    }

    setLoading(true);
    setSearchedCity(searchQuery);

    try {
      const response = await fetch(`/api/tourist-places?city=${encodeURIComponent(searchQuery.trim())}`);
      const data = await response.json();

      if (response.ok) {
        const placesWithUrls = data.places.map((place: Place) => {
          const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${place.lng - 0.01},${place.lat - 0.01},${place.lng + 0.01},${place.lat + 0.01}&layer=mapnik&marker=${place.lat},${place.lng}`;
          let directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${place.lat},${place.lng}`;
          if (userLocation) {
            directionsUrl += `&origin=${userLocation.lat},${userLocation.lng}`;
          }
          return { ...place, mapUrl, directionsUrl };
        });
        setSearchResults(placesWithUrls);
      } else {
        setSearchResults([]);
        console.error(data.error);
      }
    } catch (error) {
      setSearchResults([]);
      console.error('Failed to fetch tourist places:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container py-8">
      <PageHeader
        title="Tourist Assistance"
        description="Search for a city in India to explore its famous attractions."
      />

      <div className="mx-auto max-w-6xl space-y-8">
        <div className="flex w-full max-w-xl mx-auto items-center space-x-2">
          <Input
            type="text"
            placeholder="Enter a city name (e.g., Delhi, Mumbai, Vijayawada)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            disabled={loading}
          />
          <Button type="submit" onClick={handleSearch} disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
            Search
          </Button>
        </div>

        {loading ? (
            <div className="flex items-center justify-center pt-16">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        ) : searchedCity && (
          <div className="space-y-6">
            {searchResults.length > 0 ? (
              searchResults.map((place) => (
                <Card key={place.name} className="flex flex-col md:flex-row overflow-hidden transition-all duration-300 hover:shadow-lg">
                  <div className="md:w-3/5 flex flex-col">
                    <CardHeader>
                      <CardTitle>{place.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 flex-grow">
                      <a href={place.directionsUrl} target="_blank" rel="noopener noreferrer" className="block relative aspect-video w-full cursor-pointer group">
                        <Image
                          src={place.image.imageUrl}
                          alt={place.image.description}
                          fill
                          className="object-cover rounded-md transition-transform duration-300 group-hover:scale-105"
                          data-ai-hint={place.image.imageHint}
                        />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <p className="text-white font-semibold">Click to get directions</p>
                        </div>
                      </a>
                      <p className="flex items-center gap-3 text-sm"><Clock size={16} className="text-muted-foreground" /> <b>Timings:</b> {place.opening}</p>
                      <p className="flex items-center gap-3 text-sm"><Ticket size={16} className="text-muted-foreground" /> <b>Ticket Price:</b> {place.price}</p>
                      <p className="leading-relaxed text-muted-foreground text-sm"><b className="text-foreground">History:</b> {place.history}</p>
                    </CardContent>
                  </div>
                  <div className="md:w-2/5 min-h-[300px] md:min-h-full">
                    {place.mapUrl && (
                      <iframe
                        src={place.mapUrl}
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen={true}
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                      ></iframe>
                    )}
                  </div>
                </Card>
              ))
            ) : (
              <Alert>
                <MapPin className="h-4 w-4" />
                <AlertTitle>No Results Found</AlertTitle>
                <AlertDescription>
                  We couldn't find any tourist attractions for &quot;{searchedCity}&quot;. Please check the spelling or try another city.
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
