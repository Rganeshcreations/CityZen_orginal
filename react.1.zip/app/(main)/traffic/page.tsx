
'use client';

import { useState } from 'react';
import dynamic from 'next/dynamic';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Search, Route } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const searchSchema = z.object({
  from: z.string().min(3, 'Please enter a starting location.'),
  to: z.string().min(3, 'Please enter a destination.'),
});

type SearchFormValues = z.infer<typeof searchSchema>;

type GeoResult = { lat: number; lng: number; formattedAddress: string };

type RouteInfo = {
    distance: number;
    duration: number;
    geometry: any;
};

const LeafletMap = dynamic(() => import('@/components/shared/leaflet-map').then(mod => mod.LeafletMap), {
  ssr: false,
  loading: () => <div className="bg-muted w-full h-full animate-pulse" />
});

async function geocodeLocation(address: string): Promise<GeoResult | null> {
    try {
        const response = await fetch(`/api/geocode?address=${encodeURIComponent(address)}`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || `Failed to geocode location. Status: ${response.status}`);
        }
        
        if (data && data.length > 0) {
            const location = data[0];
            return {
                lat: parseFloat(location.lat),
                lng: parseFloat(location.lon),
                formattedAddress: location.display_name,
            };
        }
        
        return null;
    } catch (error: any) {
        console.error(`Geocoding error for ${address}:`, error.message);
        throw error;
    }
}

async function getRoute(from: GeoResult, to: GeoResult): Promise<any> {
    const url = `/api/osrm?fromLng=${from.lng}&fromLat=${from.lat}&toLng=${to.lng}&toLat=${to.lat}`;
    
    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Routing API failed with status ${response.status}`);
        }
        const data = await response.json();
        return data; // Returns an array of routes
    } catch (error) {
        console.error('Error fetching route from internal API:', error);
        throw error;
    }
}

export default function TrafficPage() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  
  const [fromLocation, setFromLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [toLocation, setToLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [routes, setRoutes] = useState<RouteInfo[]>([]);

  const searchForm = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: { from: 'India Gate, New Delhi', to: 'Red Fort, New Delhi' },
  });

  const handleSearch = async (values: SearchFormValues) => {
    setLoading(true);
    setHasSearched(true);
    setError(null);
    setFromLocation(null);
    setToLocation(null);
    setRoutes([]);

    try {
      const [fromResult, toResult] = await Promise.all([
        geocodeLocation(values.from),
        geocodeLocation(values.to),
      ]);

      if (!fromResult || !toResult) {
        setError("Could not find one or both locations. Please try different search terms.");
        setLoading(false);
        return;
      }
      
      setFromLocation({ lat: fromResult.lat, lng: fromResult.lng });
      setToLocation({ lat: toResult.lat, lng: toResult.lng });


      searchForm.setValue('from', fromResult.formattedAddress);
      searchForm.setValue('to', toResult.formattedAddress);

      const routesData = await getRoute(fromResult, toResult);
      if (routesData && routesData.length > 0) {
        setRoutes(routesData.map((route: any) => ({
            distance: route.distance,
            duration: route.duration,
            geometry: route.geometry,
        })));
      } else {
        setError('Could not find a route between these locations.');
      }

    } catch (e: any) {
      setError(e.message || "Failed to search for location. Please check your connection and try again.");
      console.error(e);
    } finally {
        setLoading(false);
    }
  };


  return (
    <div className="container py-8 flex flex-col gap-8">
      <PageHeader
        title="Live Traffic Updates"
        description="Enter a route to see real-time traffic conditions on the map."
      />

      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader><CardTitle>Search Route</CardTitle></CardHeader>
        <Form {...searchForm}>
            <form onSubmit={searchForm.handleSubmit(handleSearch)}>
                <CardContent className="space-y-4">
                    <FormField control={searchForm.control} name="from" render={({ field }) => (
                        <FormItem>
                            <FormLabel>From</FormLabel>
                            <FormControl><Input placeholder="e.g., India Gate, New Delhi" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={searchForm.control} name="to" render={({ field }) => (
                        <FormItem>
                            <FormLabel>To</FormLabel>
                            <FormControl><Input placeholder="e.g., Red Fort, New Delhi" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                </CardContent>
                <CardFooter className="flex-col sm:flex-row gap-2">
                    <Button type="submit" disabled={loading} className="w-full">
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                        Search Route
                    </Button>
                    {hasSearched && !loading && !error && fromLocation && toLocation && (
                        <Button asChild variant="outline" className="w-full">
                            <a href={`https://www.openstreetmap.org/directions?route=${fromLocation.lat}%2C${fromLocation.lng}%3B${toLocation.lat}%2C${toLocation.lng}`} target="_blank" rel="noopener noreferrer">
                                <Route className="mr-2 h-4 w-4" />
                                Directions on OSM
                            </a>
                        </Button>
                    )}
                </CardFooter>
            </form>
        </Form>
      </Card>
      
      {loading && (
        <div className="flex items-center justify-center pt-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-4 text-muted-foreground">Loading route data...</p>
        </div>
      )}

      {error && (
        <Alert variant="destructive" className="max-w-2xl mx-auto">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="h-[70vh]">
        <CardHeader>
            <CardTitle>Route Map</CardTitle>
             {routes.length > 0 && (
                <CardDescription>
                    {routes.map((route, index) => (
                        <span key={index} className="mr-4">
                            <span className={cn("font-semibold", index === 0 ? "text-green-500" : "text-orange-500")}>
                                Route {index + 1}:
                            </span>
                            {' '}{Math.round(route.distance / 1000)} km, {Math.round(route.duration / 60)} mins
                        </span>
                    ))}
                </CardDescription>
            )}
        </CardHeader>
        <CardContent className="h-[calc(70vh-80px)] p-0">
           <LeafletMap 
              fromLocation={fromLocation}
              toLocation={toLocation}
              routeGeometries={routes.map(r => r.geometry)}
           />
        </CardContent>
    </Card>
    </div>
  );
}
