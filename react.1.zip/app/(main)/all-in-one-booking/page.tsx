
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { PageHeader } from '@/components/shared/page-header';
import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Bus, CalendarIcon, Car, ChefHat, IndianRupee, Loader2, Plane, Ship, Star, Train, Utensils, Search } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { priceComparison, PriceComparisonOutput, ComparisonResult } from '@/ai/flows/all-in-one-booking-flow';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { foodData, FoodItem } from '@/data/food-data';
import Link from 'next/link';
import Image from 'next/image';

// Schemas
const travelSchema = z.object({
  from: z.string().min(3, 'Departure location is required.'),
  to: z.string().min(3, 'Destination is required.'),
  date: z.date({ required_error: 'A travel date is required.' }),
  mode: z.enum(['Bus', 'Train', 'Flight', 'Ship']),
});

const localTransportSchema = z.object({
  city: z.string({ required_error: 'Please select a city.' }),
  from: z.string().min(3, 'Pick-up location is required.'),
  to: z.string().min(3, 'Drop-off location is required.'),
});

type TravelFormValues = z.infer<typeof travelSchema>;
type LocalTransportFormValues = z.infer<typeof localTransportSchema>;
type SortOption = 'price-asc' | 'price-desc' | 'rating-desc';

const modeIcons = {
  Bus: <Bus className="h-5 w-5" />,
  Train: <Train className="h-5 w-5" />,
  Flight: <Plane className="h-5 w-5" />,
  Ship: <Ship className="h-5 w-5" />,
  Car: <Car className="h-5 w-5" />,
  Food: <ChefHat className="h-5 w-5" />,
  Hotel: <Bus className="h-5 w-5" />, // Using Bus icon as a placeholder for Hotel
};

const indianCities = [
    "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Ahmedabad", "Chennai", "Kolkata", "Surat", "Pune", "Jaipur",
    "Lucknow", "Kanpur", "Nagpur", "Indore", "Thane", "Bhopal", "Visakhapatnam", "Pimpri-Chinchwad", "Patna",
    "Vadodara", "Ghaziabad", "Ludhiana", "Agra", "Nashik", "Faridabad", "Meerut", "Rajkot", "Kalyan-Dombivali",
    "Vasai-Virar", "Varanasi", "Srinagar", "Aurangabad", "Dhanbad", "Amritsar", "Navi Mumbai", "Allahabad",
    "Ranchi", "Howrah", "Coimbatore", "Jabalpur", "Gwalior", "Vijayawada", "Jodhpur", "Madurai", "Raipur", "Kota"
];

const indianCityLocations: Record<string, string[]> = {
    "Delhi": ["Connaught Place", "India Gate", "Chandni Chowk", "Delhi Airport (DEL)", "New Delhi Railway Station", "Qutub Minar", "Hauz Khas Village"],
    "Mumbai": ["Gateway of India", "Marine Drive", "CSMT Station", "Bandra-Worli Sea Link", "Juhu Beach", "Mumbai Airport (BOM)", "Dadar"],
    "Bangalore": ["MG Road", "Koramangala", "Indiranagar", "Lalbagh Botanical Garden", "Kempegowda International Airport", "Majestic Bus Stand", "Whitefield"],
    "Pune": ["FC Road", "Koregaon Park", "Pune Railway Station", "Shaniwar Wada", "Magarpatta", "Hinjewadi"],
    "Hyderabad": ["Charminar", "Gachibowli", "Hitec City", "Rajiv Gandhi International Airport", "Secunderabad Railway Station", "Banjara Hills"],
    "Chennai": ["Marina Beach", "T. Nagar", "Chennai Central Railway Station", "Chennai International Airport", "Adyar", "Velachery"],
    "Kolkata": ["Howrah Bridge", "Park Street", "Netaji Subhas Chandra Bose International Airport", "Sealdah Railway Station", "Salt Lake (Bidhannagar)", "New Town"],
    "Jaipur": ["Hawa Mahal", "Amber Fort", "Jaipur International Airport", "Jaipur Junction Railway Station", "City Palace"],
    "Ahmedabad": ["Sabarmati Ashram", "Kankaria Lake", "Sardar Vallabhbhai Patel International Airport", "Maninagar"],
    "Vijayawada": ["Prakasam Barrage", "Kanaka Durga Temple", "Vijayawada Railway Station", "Bhavani Island", "Benz Circle"]
};

const cuisines = [
    { value: 'indian', label: 'Indian' },
    { value: 'chinese', label: 'Chinese' },
];

const foodPreferences = [
    { value: 'veg', label: 'Veg' },
    { value: 'nonveg', label: 'Non-Veg' },
];

export default function PriceComparisonPage() {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<PriceComparisonOutput | null>(null);
  const [activeTab, setActiveTab] = useState('travel');
  const [sortOption, setSortOption] = useState<SortOption>('price-asc');
  
  // State for Food Delivery Tab
  const [selectedCuisine, setSelectedCuisine] = useState<string>('indian');
  const [selectedFoodPref, setSelectedFoodPref] = useState<string>('veg');
  const [foodSearch, setFoodSearch] = useState('');
  const [selectedFoodItem, setSelectedFoodItem] = useState<FoodItem | null>(null);

  const travelForm = useForm<TravelFormValues>({
    resolver: zodResolver(travelSchema),
    defaultValues: { from: 'BOM', to: 'DEL', mode: 'Flight' },
  });

  const localTransportForm = useForm<LocalTransportFormValues>({
    resolver: zodResolver(localTransportSchema),
    defaultValues: { city: 'Delhi', from: 'Connaught Place', to: 'India Gate' },
  });

  const selectedCityForLocal = localTransportForm.watch('city');
  const locationSuggestions = useMemo(() => {
    return indianCityLocations[selectedCityForLocal] || [];
  }, [selectedCityForLocal]);


  const filteredFoodItems = useMemo(() => {
    if (!selectedCuisine || !selectedFoodPref) return [];

    try {
        const cuisineMenu = foodData[selectedCuisine as keyof typeof foodData];
        if (!cuisineMenu) return [];
        
        const items = cuisineMenu[selectedFoodPref as keyof typeof cuisineMenu] || [];
        
        if (!foodSearch.trim()) return items;
        
        return items.filter(item =>
            item.name.toLowerCase().includes(foodSearch.toLowerCase())
        );

    } catch (error) {
        console.error("Error filtering food items:", error);
        return [];
    }
  }, [selectedCuisine, selectedFoodPref, foodSearch]);

  const foodDeliveryServices = useMemo(() => {
    if (!selectedFoodItem) return [];
    
    const basePrice = Math.floor(Math.random() * 200) + 150; // Random base price between 150-350

    return [
      { name: 'Zomato', price: basePrice + Math.floor(Math.random() * 30), link: 'https://www.zomato.com' },
      { name: 'Swiggy', price: basePrice + Math.floor(Math.random() * 30), link: 'https://www.swiggy.com' }
    ].sort((a,b) => a.price - b.price);

  }, [selectedFoodItem]);


  async function handleSearch(category: 'Travel' | 'Local', data: any) {
    setLoading(true);
    setResults(null);
    try {
      let payload = { category, ...data };
      if (category === 'Travel') {
        payload = { ...payload, date: format(data.date, 'yyyy-MM-dd') };
      }
      const result = await priceComparison(payload as any);
      setResults(result);
    } catch (error) {
      console.error(`Error fetching ${category} data:`, error);
    } finally {
      setLoading(false);
    }
  }

  const onTravelSubmit = (values: TravelFormValues) => handleSearch('Travel', values);
  const onLocalTransportSubmit = (values: LocalTransportFormValues) => handleSearch('Local', values);
  
  const sortedResults = useMemo(() => {
    if (!results?.results) return [];
    
    const sorted = [...results.results];
    
    switch (sortOption) {
        case 'price-asc':
            sorted.sort((a, b) => a.price - b.price);
            break;
        case 'price-desc':
            sorted.sort((a, b) => b.price - a.price);
            break;
        case 'rating-desc':
            sorted.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
            break;
    }
    
    return sorted;
  }, [results, sortOption]);

  const ResultCard = ({ item }: { item: ComparisonResult }) => (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
            <CardTitle className="flex items-center gap-2">
                {modeIcons[item.type as keyof typeof modeIcons] || '🏨'} {item.provider}
            </CardTitle>
            {item.rating && (
                <div className="flex items-center gap-1 text-sm font-medium text-amber-500">
                    <Star className="h-4 w-4 fill-current" />
                    <span>{item.rating.toFixed(1)}</span>
                </div>
            )}
        </div>
        <CardDescription>{item.details}</CardDescription>
      </CardHeader>
      <CardContent>
        {item.duration && <p className="text-sm text-muted-foreground">Duration: {item.duration}</p>}
        {item.eta && <p className="text-sm text-muted-foreground">ETA: {item.eta}</p>}
        {item.deliveryTime && <p className="text-sm text-muted-foreground">Delivery: {item.deliveryTime}</p>}
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex flex-col">
            <span className="text-xs text-muted-foreground">Est. Price</span>
            <p className="font-bold text-lg flex items-center"><IndianRupee size={18} />{item.price.toLocaleString('en-IN')}</p>
        </div>
        {item.bookingUrl && (
          <Button asChild>
              <a href={item.bookingUrl} target="_blank" rel="noopener noreferrer">Book Now</a>
          </Button>
        )}
      </CardFooter>
    </Card>
  );

  const renderResults = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center pt-16">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Fetching comparisons...</p>
        </div>
      );
    }
    
    if (!results) return null;

    if (sortedResults.length > 0) {
      const titleMap = {
        'Travel': 'Travel Options',
        'Local': 'Car Rental Options',
      };
      
      const currentCategory = sortedResults[0].category as keyof typeof titleMap;

      return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">{titleMap[currentCategory]}</h3>
                <Select value={sortOption} onValueChange={(value) => setSortOption(value as SortOption)}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="price-asc">Price: Low to High</SelectItem>
                        <SelectItem value="price-desc">Price: High to Low</SelectItem>
                        <SelectItem value="rating-desc">Rating</SelectItem>
                    </SelectContent>
                </Select>
            </div>
          {sortedResults.map((item, index) => (
            <ResultCard key={index} item={item} />
          ))}
        </div>
      );
    }
    
    if (!loading && results && sortedResults.length === 0) {
        return (
            <div className="text-center text-muted-foreground pt-16">
                <p>No results found for your search criteria.</p>
                <p className="text-sm">Please try different options.</p>
            </div>
        )
    }

    return null;
  };

  return (
    <>
    <div className="container py-8">
      <PageHeader
        title="Price Comparison"
        description="Compare prices for travel and local transport, or browse food delivery menus."
      />

      <div className="mx-auto max-w-2xl space-y-8">
        <Tabs defaultValue="travel" value={activeTab} onValueChange={(value) => { setResults(null); setActiveTab(value); }} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="travel">Travel</TabsTrigger>
            <TabsTrigger value="local">Local Transport</TabsTrigger>
            <TabsTrigger value="food">Food Delivery</TabsTrigger>
          </TabsList>

          {/* Travel Tab */}
          <TabsContent value="travel">
            <Card>
              <CardHeader>
                <CardTitle>Compare Travel Options</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...travelForm}>
                  <form onSubmit={travelForm.handleSubmit(onTravelSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField name="from" control={travelForm.control} render={({ field }) => (
                          <FormItem><FormLabel>From</FormLabel><FormControl><Input placeholder="e.g., BOM" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField name="to" control={travelForm.control} render={({ field }) => (
                          <FormItem><FormLabel>To</FormLabel><FormControl><Input placeholder="e.g., DEL" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>
                     <FormDescription>For flights, use IATA airport codes for best results (e.g., BOM for Mumbai).</FormDescription>
                     <FormField name="date" control={travelForm.control} render={({ field }) => (
                      <FormItem className="flex flex-col"><FormLabel>Date of Travel</FormLabel><Popover><PopoverTrigger asChild>
                        <FormControl><Button variant={'outline'} className={cn('pl-3 text-left font-normal', !field.value && 'text-muted-foreground')}>
                          {field.value ? format(field.value, 'LLL dd, y') : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button></FormControl>
                      </PopoverTrigger><PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                      </PopoverContent></Popover><FormMessage /></FormItem>
                    )} />
                    <FormField name="mode" control={travelForm.control} render={({ field }) => (
                        <FormItem><FormLabel>Mode of Travel</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Select a mode" /></SelectTrigger></FormControl>
                            <SelectContent>
                            <SelectItem value="Flight">Flight</SelectItem>
                            <SelectItem value="Train">Train</SelectItem>
                            <SelectItem value="Bus">Bus</SelectItem>
                            <SelectItem value="Ship">Ship</SelectItem>
                            </SelectContent>
                        </Select><FormMessage /></FormItem>
                    )} />
                    <Button type="submit" disabled={loading} className="w-full">
                      {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Search Travel
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Local Transport Tab */}
          <TabsContent value="local">
             <datalist id="location-suggestions">
                {locationSuggestions.map(loc => (
                    <option key={loc} value={loc} />
                ))}
            </datalist>
            <Card>
                <CardHeader><CardTitle>Compare Car Rentals</CardTitle></CardHeader>
                <CardContent>
                    <Form {...localTransportForm}>
                        <form onSubmit={localTransportForm.handleSubmit(onLocalTransportSubmit)} className="space-y-6">
                             <FormField
                                control={localTransportForm.control}
                                name="city"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>City</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a city" />
                                        </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                        {indianCities.map(city => (
                                            <SelectItem key={city} value={city}>{city}</SelectItem>
                                        ))}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField name="from" control={localTransportForm.control} render={({ field }) => (
                                <FormItem><FormLabel>Pick-up Location</FormLabel><FormControl><Input placeholder="e.g., 'JFK Airport, NY'" {...field} list="location-suggestions" /></FormControl><FormMessage /></FormItem>
                            )} />
                             <FormField name="to" control={localTransportForm.control} render={({ field }) => (
                                <FormItem><FormLabel>Drop-off Location</FormLabel><FormControl><Input placeholder="e.g., 'Manhattan, NY'" {...field} list="location-suggestions" /></FormControl><FormMessage /></FormItem>
                            )} />
                            <Button type="submit" disabled={loading} className="w-full">
                                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Search Rentals
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
          </TabsContent>

          {/* Food Delivery Tab */}
          <TabsContent value="food">
             <Card>
                <CardHeader>
                  <CardTitle>Browse Food Menu</CardTitle>
                  <CardDescription>Select a cuisine and preference, then search for and select an item to see delivery options.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                           <Label htmlFor="cuisine-select">Cuisine</Label>
                           <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
                                <SelectTrigger id="cuisine-select">
                                    <SelectValue placeholder="Select Cuisine" />
                                </SelectTrigger>
                                <SelectContent>
                                    {cuisines.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                         <div className="space-y-2">
                           <Label htmlFor="pref-select">Preference</Label>
                           <Select value={selectedFoodPref} onValueChange={setSelectedFoodPref}>
                                <SelectTrigger id="pref-select">
                                    <SelectValue placeholder="Select Preference" />
                                </SelectTrigger>
                                <SelectContent>
                                    {foodPreferences.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    
                    <div className="relative">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                            placeholder="Search for an item..."
                            className="pl-8"
                            value={foodSearch}
                            onChange={(e) => setFoodSearch(e.target.value)}
                        />
                    </div>

                    {filteredFoodItems.length > 0 && (
                        <div className="space-y-2 pt-4">
                             <h4 className="font-semibold text-center">Available Items</h4>
                             <div className="max-h-[400px] overflow-y-auto rounded-md border p-2">
                                <ul className="space-y-1">
                                    {filteredFoodItems.map(item => (
                                        <li
                                            key={item.name}
                                            onClick={() => setSelectedFoodItem(item)}
                                            className={cn(
                                                "cursor-pointer rounded-md p-2 text-sm text-muted-foreground transition-colors hover:bg-accent flex items-center gap-4",
                                                selectedFoodItem?.name === item.name && "bg-primary text-primary-foreground hover:bg-primary/90"
                                            )}
                                        >
                                            <Image 
                                                src={item.image.imageUrl}
                                                alt={item.image.description}
                                                width={80}
                                                height={80}
                                                className="rounded-md object-cover"
                                                data-ai-hint={item.image.imageHint}
                                            />
                                            <span>{item.name}</span>
                                        </li>
                                    ))}
                                </ul>
                             </div>
                        </div>
                    )}
                    
                     {selectedCuisine && selectedFoodPref && filteredFoodItems.length === 0 && (
                         <p className="text-center text-muted-foreground pt-8">No items found for this selection.</p>
                     )}
                     
                     {selectedFoodItem && (
                        <div className="space-y-4 pt-6 animate-in fade-in-50">
                             <h4 className="font-semibold text-center">Delivery Options for {selectedFoodItem.name}</h4>
                             {foodDeliveryServices.map(service => (
                                <Card key={service.name}>
                                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                                        <CardTitle className="text-base font-medium">{service.name}</CardTitle>
                                        <p className="font-bold text-lg flex items-center"><IndianRupee size={16} />{service.price.toLocaleString('en-IN')}</p>
                                    </CardHeader>
                                    <CardFooter>
                                        <Button asChild className="w-full">
                                            <Link href={service.link} target="_blank" rel="noopener noreferrer">Order Now</Link>
                                        </Button>
                                    </CardFooter>
                                </Card>
                             ))}
                        </div>
                     )}
                </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="mt-8">
            {activeTab !== 'food' && renderResults()}
        </div>
      </div>
    </div>
    </>
  );
}

    

    