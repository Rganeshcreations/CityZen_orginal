
'use client';

import { useState, useEffect } from 'react';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { User, Briefcase, Star, MapPin, Phone, Shield, Bug, Shirt, Loader2 } from 'lucide-react';
import Link from 'next/link';

type Worker = {
  name: string;
  phone: string;
  rating: string;
  location: string;
};

type CityData = Record<string, Worker[]>;
type AllData = Record<string, CityData>;

const jobIcons: Record<string, React.ReactNode> = {
  'Plumber': <Briefcase />, 'Electrician': <Briefcase />, 'Mechanic': <Briefcase />,
  'Carpenter': <Briefcase />, 'Painter': <Briefcase />, 'AC Repair': <Briefcase />,
  'Security Guards': <Shield />, 'Pest Control': <Bug />, 'Laundry': <Shirt />,
  'default': <User />
};

const renderWithLink = (text: string) => {
  const parts = text.split(/(Justdial)/gi);
  return parts.map((part, index) =>
    part.toLowerCase() === 'justdial' ? (
      <Link
        key={index}
        href="https://www.justdial.com"
        target="_blank"
        rel="noopener noreferrer"
        className="text-primary underline hover:text-primary/80"
      >
        {part}
      </Link>
    ) : (
      part
    )
  );
};

export default function OtherServicesPage() {
  const [cities, setCities] = useState<string[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [jobs, setJobs] = useState<string[]>([]);
  const [selectedJob, setSelectedJob] = useState<string>('');
  const [results, setResults] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);
  const [resultsLoading, setResultsLoading] = useState(false);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await fetch('/api/services?cities=true');
        const data = await response.json();
        setCities(data.cities);
      } catch (error) {
        console.error("Failed to fetch cities:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCities();
  }, []);

  const handleCityChange = async (city: string) => {
    setSelectedCity(city);
    setSelectedJob('');
    setResults([]);
    if (city) {
      setLoading(true);
      try {
        const response = await fetch(`/api/services?city=${city}&jobs=true`);
        const data = await response.json();
        setJobs(data.jobs);
      } catch (error) {
        console.error(`Failed to fetch jobs for ${city}:`, error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleJobChange = async (job: string) => {
    setSelectedJob(job);
    if (selectedCity && job) {
      setResultsLoading(true);
      try {
        const response = await fetch(`/api/services?city=${selectedCity}&job=${job}`);
        const data = await response.json();
        setResults(data.workers);
      } catch (error) {
        console.error(`Failed to fetch workers for ${job} in ${selectedCity}:`, error);
      } finally {
        setResultsLoading(false);
      }
    }
  };
  
  const getPhoneNumber = (phone: string) => {
    const match = phone.match(/(\d{10,})/);
    return match ? match[0] : null;
  };

  return (
    <div className="container py-8">
      <PageHeader
        title="Other Services"
        description="Find and contact local service professionals in your city."
      />

      <div className="max-w-2xl mx-auto space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Find a Professional</CardTitle>
            <CardDescription>Select your city and the type of service you need.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block mb-2 font-medium text-sm">Select City:</label>
              <Select onValueChange={handleCityChange} value={selectedCity} disabled={loading}>
                <SelectTrigger>
                  <SelectValue placeholder={loading ? "Loading cities..." : "-- Choose City --"} />
                </SelectTrigger>
                <SelectContent>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedCity && (
              <div>
                <label className="block mb-2 font-medium text-sm">Select Service Type:</label>
                <Select onValueChange={handleJobChange} value={selectedJob} disabled={loading}>
                  <SelectTrigger>
                    <SelectValue placeholder={loading ? "Loading services..." : "-- Choose Service --"} />
                  </SelectTrigger>
                  <SelectContent>
                    {jobs.map((job) => (
                      <SelectItem key={job} value={job}>
                        {job}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>
        
        {resultsLoading && (
            <div className="flex justify-center items-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        )}

        {selectedCity && selectedJob && !resultsLoading && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-center">
              Available {selectedJob}s in {selectedCity}
            </h2>

            {results.length > 0 ? (
              results.map((worker, index) => {
                const tel = getPhoneNumber(worker.phone);
                return (
                    <Card key={index}>
                        <CardHeader>
                        <CardTitle className="flex items-center gap-2">{jobIcons[selectedJob] || jobIcons['default']} {worker.name}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <p className="flex items-center gap-3"><Phone size={16} className="text-muted-foreground" /> <strong>Contact:</strong> {renderWithLink(worker.phone)}</p>
                            <p className="flex items-center gap-3"><Star size={16} className="text-muted-foreground" /> <strong>Rating:</strong> {renderWithLink(worker.rating)}</p>
                            <p className="flex items-center gap-3"><MapPin size={16} className="text-muted-foreground" /> <strong>Location:</strong> {worker.location}</p>
                        </CardContent>
                        {tel && (
                           <CardContent>
                                <Button asChild className="w-full">
                                    <a href={`tel:${tel}`}>
                                        <Phone className="mr-2 h-4 w-4" /> Call Now
                                    </a>
                                </Button>
                           </CardContent>
                        )}
                    </Card>
                )
            })
            ) : (
                <p className="text-center text-muted-foreground pt-4">
                    No {selectedJob}s found in {selectedCity}. Please check back later.
                </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
