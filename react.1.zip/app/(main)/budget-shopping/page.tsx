
'use client';

import { useState } from 'react';
import Image from 'next/image';
import { PageHeader } from '@/components/shared/page-header';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { IndianRupee, Search, ShoppingCart, Star } from 'lucide-react';
import Link from 'next/link';
import { placeholderImages } from '@/lib/placeholder-images.json';
import type { ImagePlaceholder, Product as ProductItem, Vendor } from '@/lib/types';
import { VendorIcon } from '@/components/shared/vendor-icons';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

const findImage = (id: string): ImagePlaceholder => {
  const image = placeholderImages.find((img) => img.id === id);
  if (!image) throw new Error(`Image with id "${id}" not found.`);
  return image;
};

type ItemData = Record<string, ProductItem[]>;

const productDatabase: ItemData = {
    mobile: [
        { id: 'iphone15', name: 'Apple iPhone 15 (128GB)', image: findImage('shopping-iphone-15'), rating: 4.6, vendors: [
            { name: 'Amazon', price: 52990, link: 'https://www.amazon.in/dp/B0CHX2WZV9' },
            { name: 'Flipkart', price: 53990, link: 'https://www.flipkart.com/apple-iphone-15-blue-128-gb/p/itwa9768f5c3a58d' },
            { name: 'Croma', price: 55990, link: 'https://www.croma.com/apple-iphone-15-128gb-blue/p/300971' },
        ]},
        { id: 's24', name: 'Samsung Galaxy S24', image: findImage('shopping-samsung-s24'), rating: 4.5, vendors: [
            { name: 'Amazon', price: 47999, link: 'https://www.amazon.in/dp/B0CS5Y2Y3Q' },
            { name: 'Reliance Digital', price: 48500, link: 'https://www.reliancedigital.in/samsung-galaxy-s24-5g-128-gb-8-gb-ram-onyx-black-smartphone/p/494352125' },
        ]},
        { id: 'nordce3', name: 'OnePlus Nord CE 3 Lite 5G', image: findImage('shopping-phone'), rating: 4.4, vendors: [
            { name: 'OnePlus', price: 17999, link: 'https://www.oneplus.in' },
            { name: 'Amazon', price: 17999, link: 'https://www.amazon.in/dp/B0BY8MCQ9S' },
        ]},
    ],
    laptop: [
        { id: 'dell15', name: 'Dell Inspiron 15', image: findImage('shopping-dell-laptop'), rating: 4.2, vendors: [
            { name: 'Amazon', price: 42990, link: 'https://www.amazon.in/dp/B0BTHS1FR6' },
            { name: 'Flipkart', price: 43500, link: 'https://www.flipkart.com/dell-inspiron-15-intel-core-i5-12th-gen-1235u-16-gb-512-gb-ssd-windows-11-home-2-in-1-laptop/p/itme522d1a33599a' },
        ]},
        { id: 'hp15s', name: 'HP 15s, Ryzen 5 5500U', image: findImage('shopping-laptop'), rating: 4.3, vendors: [
            { name: 'Amazon', price: 45990, link: 'https://www.amazon.in/dp/B0C32N9L75' },
        ]},
        { id: 'macbookm1', name: 'Apple MacBook Air M1', image: findImage('shopping-macbook-air'), rating: 4.8, vendors: [
            { name: 'Reliance Digital', price: 84990, link: 'https://www.reliancedigital.in/apple-macbook-air-m1-chip-13-3-inch-retina-display-8-gb-256-gb-ssd-30w-usb-c-power-adapter-space-grey-2020-/p/491977227' },
            { name: 'Flipkart', price: 83990, link: 'https://www.flipkart.com/apple-2020-macbook-air-m1-8-gb-256-gb-ssd-mac-os-big-sur-mgn63hn-a/p/itm9e18355824767' },
        ]},
    ],
    tv: [
        { id: 'lgtv55', name: 'LG 55" QLED TV', image: findImage('shopping-lg-tv'), rating: 4.3, vendors: [
            { name: 'Amazon', price: 32999, link: 'https://www.amazon.in/dp/B0D5T1W9N8' },
        ]},
        { id: 'sonytv43', name: 'Sony Bravia 43" 4K Ultra HD', image: findImage('shopping-tv'), rating: 4.7, vendors: [
            { name: 'Croma', price: 42990, link: 'https://www.croma.com/sony-bravia-108-cm-43-inch-4k-ultra-hd-led-google-tv-with-google-assistant-2023-model-kd-43x75l-/p/272216' },
            { name: 'Reliance Digital', price: 43990, link: 'https://www.reliancedigital.in/sony-bravia-108-cm-43-inch-4k-ultra-hd-smart-led-google-tv-kd-43x75l-black-/p/493664878' },
        ]},
        { id: 'samsungtv43', name: 'Samsung Crystal 4K Neo 43"', image: findImage('shopping-samsung-tv'), rating: 4.4, vendors: [
            { name: 'Flipkart', price: 31990, link: 'https://www.flipkart.com/samsung-crystal-4k-neo-series-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2022-model/p/itm9571a39703512' },
            { name: 'Amazon', price: 30990, link: 'https://www.amazon.in/Samsung-Crystal-Ultra-Smart-UA43AUE65AKXXL/dp/B0B4F2T74B' },
        ]},
    ],
    headphones: [
        { id: 'sonyxm5', name: 'Sony WH-1000XM5', image: findImage('shopping-sony-xm5'), rating: 4.7, vendors: [
            { name: 'Amazon', price: 24990, link: 'https://www.amazon.in/dp/B0B4WW9H2Y' },
            { name: 'Croma', price: 25990, link: 'https://www.croma.com/sony-wh-1000xm5-wireless-noise-cancelling-headphones-with-mic-30-hours-playback-bluetooth-5-2-black-/p/259468' },
        ]},
        { id: 'boseqc', name: 'Bose QuietComfort Ultra', image: findImage('shopping-bose-qc'), rating: 4.6, vendors: [
            { name: 'Amazon', price: 31900, link: 'https://www.amazon.in/dp/B0CCZ26146' },
        ]},
        { id: 'airpodspro', name: 'Apple AirPods Pro (2nd Gen)', image: findImage('shopping-airpods-pro'), rating: 4.7, vendors: [
            { name: 'Amazon', price: 22990, link: 'https://www.amazon.in/dp/B0BDJ379Q5' },
            { name: 'Flipkart', price: 23990, link: 'https://www.flipkart.com/apple-airpods-pro-2nd-generation-charging-case-magsafe-bluetooth-headset/p/itm92c6762391b4b' },
        ]}
    ],
    speaker: [
        { id: 'jblflip6', name: 'JBL Flip 6', image: findImage('shopping-jbl-flip6'), rating: 4.4, vendors: [
            { name: 'Amazon', price: 7498, link: 'https://www.amazon.in/dp/B09H5XPD37' },
            { name: 'Flipkart', price: 7999, link: 'https://www.flipkart.com/jbl-flip-6-with-pro-sound-20-w-bluetooth-speaker/p/itmd4133da268688' },
        ]}
    ],
    fridge: [
        { id: 'samsungfridge322', name: 'Samsung 322L Double Door', image: findImage('shopping-samsung-fridge'), rating: 4.4, vendors: [
            { name: 'Amazon', price: 34490, link: 'https://www.amazon.in/dp/B0C7BYSY87' },
        ]},
        { id: 'lgfridge242', name: 'LG 242L Double Door', image: findImage('shopping-lg-fridge'), rating: 4.3, vendors: [
            { name: 'Amazon', price: 25990, link: 'https://www.amazon.in/dp/B0CS2S524H' },
        ]},
        { id: 'whirlpoolfridge240', name: 'Whirlpool 240L Double Door', image: findImage('shopping-whirlpool-fridge'), rating: 4.2, vendors: [
            { name: 'Amazon', price: 25790, link: 'https://www.amazon.in/dp/B0CPL3G4S9' },
        ]}
    ],
    smartwatch: [
        { id: 'applewatch9', name: 'Apple Watch Series 9', image: findImage('shopping-apple-watch'), rating: 4.7, vendors: [
            { name: 'Amazon', price: 41900, link: 'https://www.amazon.in/dp/B0CHX9S15S' },
        ]},
        { id: 'galaxywatch6', name: 'Samsung Galaxy Watch6', image: findImage('shopping-galaxy-watch'), rating: 4.5, vendors: [
            { name: 'Amazon', price: 29999, link: 'https://www.amazon.in/dp/B0C7QYXC2B' },
        ]},
        { id: 'fitbitversa4', name: 'Fitbit Versa 4', image: findImage('shopping-fitbit-versa'), rating: 4.2, vendors: [
            { name: 'Amazon', price: 16999, link: 'https://www.amazon.in/dp/B0B4M64T17' },
        ]}
    ],
    tablet: [
        { id: 'ipad10', name: 'Apple iPad (10th Generation)', image: findImage('shopping-ipad'), rating: 4.6, vendors: [
            { name: 'Amazon', price: 33900, link: 'https://www.amazon.in/dp/B0BJLXM345' },
        ]},
        { id: 'galaxytab', name: 'Samsung Galaxy Tab S9 FE', image: findImage('shopping-galaxy-tab'), rating: 4.5, vendors: [
            { name: 'Amazon', price: 30999, link: 'https://www.amazon.in/dp/B0CHY5T5Y6' },
        ]}
    ],
    rice: [
        { id: 'indiagate', name: 'India Gate Basmati Rice (1kg)', image: findImage('shopping-rice'), rating: 4.5, vendors: [
            { name: 'Amazon', price: 120, link: 'https://www.amazon.in' },
            { name: 'Flipkart', price: 115, link: 'https://www.flipkart.com' }
        ]},
    ],
};

export default function BudgetShoppingPage() {
  const [search, setSearch] = useState("");
  const [result, setResult] = useState<ProductItem[] | null>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = () => {
    const searchKey = search.replace(/\s/g, "").toLowerCase();
    setSearched(true);

    if (productDatabase[searchKey]) {
      const items = productDatabase[searchKey];
      setResult(items);
    } else {
      setResult(null);
    }
  };
  
  const ResultCard = ({ item }: { item: ProductItem }) => {
    const sortedVendors = [...item.vendors].sort((a, b) => a.price - b.price);
    const bestPrice = sortedVendors[0]?.price;
    
    return (
        <Card className="flex flex-col overflow-hidden transition-all duration-300 hover:shadow-xl">
            <CardHeader>
                <div className="relative w-full h-48">
                    <Image 
                        src={item.image.imageUrl}
                        alt={item.image.description}
                        fill
                        className="object-contain"
                        data-ai-hint={item.image.imageHint}
                    />
                </div>
                 <div className="mt-4">
                    <CardTitle className="leading-tight text-lg h-12 overflow-hidden">{item.name}</CardTitle>
                    {item.rating && (
                        <div className="flex items-center gap-1 text-sm text-amber-500 mt-1">
                            <Star className="h-4 w-4 fill-current" />
                            <span>{item.rating.toFixed(1)}</span>
                        </div>
                    )}
                </div>
            </CardHeader>
            <CardContent className="flex flex-col flex-grow pt-2">
                 <div className="space-y-2">
                    <p className="text-xs text-muted-foreground font-semibold">COMPARE PRICES</p>
                    {sortedVendors.map((vendor, index) => (
                        <div key={vendor.name + index}>
                            <div className="flex items-center justify-between gap-4">
                                <div className="flex items-center gap-2">
                                    <VendorIcon vendor={vendor.name} />
                                    <span className="text-sm font-medium">{vendor.name}</span>
                                </div>
                                <div className="flex items-center gap-4">
                                     <p className={cn(
                                        "font-bold text-base flex items-center",
                                        vendor.price === bestPrice ? "text-primary" : "text-foreground"
                                     )}>
                                        <IndianRupee size={14}/>{vendor.price.toLocaleString('en-IN')}
                                    </p>
                                    <Button asChild size="sm" variant="outline">
                                        <Link href={vendor.link} target="_blank" rel="noopener noreferrer">
                                            View Deal
                                        </Link>
                                    </Button>
                                </div>
                            </div>
                           {index < sortedVendors.length - 1 && <Separator className="my-2" />}
                        </div>
                    ))}
                 </div>
            </CardContent>
        </Card>
    );
  };

  return (
    <div className="container py-8">
      <PageHeader
        title="Budget Shopping"
        description="Search for products to find the best prices and options from various companies."
      />

      <div className="max-w-6xl mx-auto space-y-8">
        <Card>
            <CardHeader>
                <CardTitle>Find the Best Deal</CardTitle>
                <CardDescription>
                  Search for products to find the best prices and options from various companies.
                </CardDescription>
            </CardHeader>
            <CardContent>
                 <div className="flex w-full items-center space-x-2">
                    <Input
                        type="text"
                        placeholder="e.g., mobile, laptop, tv, fridge, smartwatch, tablet..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                    <Button onClick={handleSearch}><Search className="h-4 w-4 mr-2"/>Search</Button>
                </div>
            </CardContent>
        </Card>

        {searched && (
            <div className="space-y-4">
                {result ? (
                   <div>
                     <h2 className="text-2xl font-bold mb-4">Showing results for &quot;{search}&quot;</h2>
                      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                          {result.map((item, index) => (
                              <ResultCard key={`${item.id}-${index}`} item={item} />
                          ))}
                      </div>
                   </div>
                ) : (
                    <Alert>
                        <ShoppingCart className="h-4 w-4" />
                        <AlertTitle>Item Not Found</AlertTitle>
                        <AlertDescription>
                           We couldn't find products for &quot;{search}&quot;. Try searching for: mobile, laptop, tv, fridge, headphones, speaker, smartwatch, tablet, or rice.
                        </AlertDescription>
                    </Alert>
                )}
            </div>
        )}
      </div>
    </div>
  );
}

    