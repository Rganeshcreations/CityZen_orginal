
'use client';

import { useState, useRef, useEffect, Suspense, lazy } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Image from 'next/image';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, CheckCircle, Send, AlertCircle, FileCheck, Calendar, Shield, Mail, LocateFixed, MapPin } from 'lucide-react';
import { reportIssue, ReportOutput } from '@/ai/flows/diagnose-issue-flow';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { format } from 'date-fns';
import { Timestamp } from 'firebase/firestore';

const LeafletMap = lazy(() => import('@/components/shared/leaflet-map').then(mod => ({ default: mod.LeafletMap })));


const issueCategories = [
    'Road Damage',
    'Water Leakage',
    'Streetlight Outage',
    'Garbage Overflow',
    'Traffic Issue',
    'Public Vandalism',
    'Pollution',
    'Other'
];

const reportSchema = z.object({
  issueType: z.string().min(1, "Please select an issue type."),
  description: z.string().min(10, "Please provide a detailed description."),
  image: z.instanceof(File).refine(file => !!file, "An image is required."),
  location: z.string().min(10, "Please provide a specific location or use your current location."),
});

type ReportFormValues = z.infer<typeof reportSchema>;
type Coords = { lat: number; lng: number };

async function reverseGeocode(coords: { lat: number; lng: number }): Promise<string | null> {
    try {
        const response = await fetch(`/api/reverse-geocode?lat=${coords.lat}&lon=${coords.lng}`);
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Reverse geocoding failed with status: ${response.status}`);
        }
        const data = await response.json();
        return data.display_name || null;
    } catch (error) {
        console.error("Reverse geocoding error:", error);
        return null;
    }
}


export default function IssueReportingPage() {
  const [loading, setLoading] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<ReportOutput | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [coords, setCoords] = useState<Coords>({ lat: 20.5937, lng: 78.9629 }); // Default to India
  const [isMapVisible, setMapVisible] = useState(false);
  
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const methods = useForm<ReportFormValues>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
        issueType: '',
        description: '',
        location: '',
        image: undefined,
    }
  });

  const handleFileClick = () => fileInputRef.current?.click();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      methods.setValue('image', file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleUseCurrentLocation = async () => {
      setLoading(true);
      if (!navigator.geolocation) {
          toast({ variant: 'destructive', title: "Geolocation Not Supported", description: "Your browser does not support geolocation." });
          setLoading(false);
          return;
      }

      navigator.geolocation.getCurrentPosition(
          async (position) => {
              const { latitude, longitude } = position.coords;
              try {
                const address = await reverseGeocode({ lat: latitude, lng: longitude });
                if (address) {
                    methods.setValue('location', address);
                    setCoords({ lat: latitude, lng: longitude });
                    toast({ title: "Location Found!", description: "Your current location has been set." });
                } else {
                    toast({ variant: 'destructive', title: "Could Not Find Address", description: "Unable to find a street address for your coordinates." });
                }
              } catch (error: any) {
                  toast({ variant: 'destructive', title: "Reverse Geocoding Failed", description: error.message });
              } finally {
                  setLoading(false);
              }
          },
          (error) => {
              toast({ variant: 'destructive', title: "Geolocation Failed", description: error.message });
              setLoading(false);
          }
      );
  };
  
  const handleMapPinMove = async (lat: number, lng: number) => {
    setCoords({ lat, lng });
    const address = await reverseGeocode({ lat, lng });
    if (address) {
        methods.setValue('location', address, { shouldValidate: true });
    }
  };
  
  const onSubmit = async (data: ReportFormValues) => {
    setLoading(true);
    setSubmissionResult(null);

    try {
        if (!data.image) {
            throw new Error("Image is required for submission.");
        }
        
        // This is a mock submission as per the latest changes
        const mockResult: ReportOutput = {
            reportId: `mock_${new Date().getTime()}`,
            departmentEmailed: 'Mock Department',
            category: data.issueType,
            location: data.location,
            timestamp: Timestamp.now(),
        };

        setSubmissionResult(mockResult);
        toast({ title: "Report Submitted!", description: "Your issue has been successfully submitted and forwarded to the local government officers of Andhra Pradesh. They will review and take action soon." });

    } catch (error: any) {
        toast({ variant: 'destructive', title: "Submission Failed", description: error.message || "An unknown error occurred." });
    } finally {
        setLoading(false);
    }
  };
  
  const resetForm = () => {
      methods.reset();
      setSubmissionResult(null);
      setImagePreview(null);
      if (fileInputRef.current) {
          fileInputRef.current.value = '';
      }
  }

  if (submissionResult) {
    return (
        <div className="container py-8 flex flex-col items-center gap-6">
            <PageHeader title="Report Submitted" description="Thank you for helping improve our city." />
             <Card className="w-full max-w-lg">
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4">
                     {submissionResult.failureReason ? <AlertCircle className="h-16 w-16 text-destructive" /> : <CheckCircle className="h-16 w-16 text-green-500" />}
                  </div>
                  <CardTitle>{submissionResult.failureReason ? "Submission Failed" : "Submission Successful"}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {submissionResult.failureReason ? (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Error</AlertTitle>
                      <AlertDescription>{submissionResult.failureReason}</AlertDescription>
                    </Alert>
                  ) : (
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground flex items-center gap-2"><FileCheck size={16}/> Report ID</span>
                        <span className="font-mono bg-muted p-1 rounded-sm text-xs">{submissionResult.reportId?.substring(0, 10)}...</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground flex items-center gap-2"><Calendar size={16}/> Timestamp</span>
                        <span>{submissionResult.timestamp ? format(submissionResult.timestamp.toDate(), 'PPpp') : 'N/A'}</span>
                      </div>
                       <div className="flex justify-between items-center">
                        <span className="text-muted-foreground flex items-center gap-2"><Shield size={16}/> Category</span>
                        <span>{submissionResult.category}</span>
                      </div>
                       <div className="flex justify-between items-start">
                        <span className="text-muted-foreground flex items-center gap-2 pt-1"><MapPin size={16}/> Location</span>
                        <span className="text-right max-w-[70%]">{submissionResult.location}</span>
                      </div>
                       <div className="flex justify-between items-center">
                        <span className="text-muted-foreground flex items-center gap-2"><Mail size={16}/> Department Notified</span>
                        <span className="text-right">{submissionResult.departmentEmailed}</span>
                      </div>
                       {imagePreview && (
                            <div className="mt-4 flex justify-center">
                                <Image src={imagePreview} alt="Submitted photo" width={200} height={200} className="rounded-md object-cover" />
                            </div>
                        )}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                    <Button onClick={resetForm} className="w-full">Report Another Issue</Button>
                </CardFooter>
             </Card>

              {!submissionResult.failureReason && (
                <Alert className="w-full max-w-lg">
                    <CheckCircle className="h-4 w-4" />
                    <AlertTitle>Status Update</AlertTitle>
                    <AlertDescription>
                       Your issue has been successfully submitted and forwarded to the local government officers of Andhra Pradesh. They will review and take action soon.
                    </AlertDescription>
                </Alert>
              )}
        </div>
    );
  }


  return (
    <div className="container py-8">
      <PageHeader
        title="Report a Civic Issue"
        description="Help us improve your city by reporting problems like potholes, graffiti, or broken streetlights."
      />
      
      <FormProvider {...methods}>
        <form onSubmit={methods.handleSubmit(onSubmit)} className="w-full max-w-2xl mx-auto">
          <Card>
            <CardHeader>
                <CardTitle>Report Details</CardTitle>
                <CardDescription>Provide a description, photo, and location of the issue.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">

                <FormField
                    control={methods.control}
                    name="issueType"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Issue Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select the type of issue" />
                                </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {issueCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                <FormField
                    control={methods.control}
                    name="description"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                            <Textarea placeholder="e.g., 'Large pothole on the main road near the city park.'" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                
                 <FormField
                    control={methods.control}
                    name="image"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Photo of the Issue</FormLabel>
                        <FormControl>
                            <div>
                            <Input
                                type="file"
                                className="hidden"
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                accept="image/*"
                            />
                            <Button variant="outline" type="button" onClick={handleFileClick} className="w-full">
                                <Upload className="mr-2" />
                                {imagePreview ? "Change Photo" : "Upload Photo"}
                            </Button>
                            </div>
                        </FormControl>
                        {imagePreview && (
                            <div className="mt-4 flex justify-center">
                                <Image src={imagePreview} alt="Image preview" width={200} height={200} className="rounded-md object-cover" />
                            </div>
                        )}
                        <FormMessage />
                        </FormItem>
                    )}
                />

                <FormField
                    control={methods.control}
                    name="location"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Location</FormLabel>
                         <div className="flex gap-2">
                             <FormControl>
                                <Input placeholder="e.g., 'Near City Park, New Delhi' or use map below" {...field} />
                            </FormControl>
                            <Button type="button" variant="outline" onClick={handleUseCurrentLocation} disabled={loading} title="Use Current Location">
                                <LocateFixed className="h-4 w-4" />
                            </Button>
                         </div>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                
                <div>
                  <Button type="button" variant="outline" className="w-full" onClick={() => setMapVisible(!isMapVisible)}>
                    <MapPin className="mr-2" />
                    {isMapVisible ? 'Hide Map' : 'Select Location on Map'}
                  </Button>

                  {isMapVisible && (
                     <div className="mt-4 h-96 w-full rounded-md overflow-hidden relative">
                        <Suspense fallback={<div className="h-full w-full flex items-center justify-center bg-muted"><Loader2 className="animate-spin"/></div>}>
                           <LeafletMap 
                                isDraggable 
                                center={coords}
                                onMove={handleMapPinMove}
                            />
                        </Suspense>
                     </div>
                  )}
                </div>

            </CardContent>
            <CardFooter>
                <Button type="submit" disabled={loading} className="w-full">
                    {loading && <Loader2 className="animate-spin mr-2" />}
                    Submit Report
                </Button>
            </CardFooter>
          </Card>
        </form>
      </FormProvider>
    </div>
  );
}
