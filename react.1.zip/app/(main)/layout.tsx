
'use client';

import { Header } from '@/components/shared/header';
import { useUser, useUserProfile } from '@/hooks/use-user';
import { SplashScreen } from '@/app/splash-screen';
import { Redirect } from '@/components/shared/redirect';
import { usePathname } from 'next/navigation';
import { AnimatePresence, motion } from 'framer-motion';

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, loading: userLoading } = useUser();
  const { userProfile, loading: profileLoading } = useUserProfile(user?.uid);
  const pathname = usePathname();

  const isLoading = userLoading || profileLoading;

  if (isLoading) {
    return <SplashScreen />;
  }
  
  if (!user && !isLoading) {
    return <Redirect to="/login" />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <AnimatePresence mode="wait">
        <motion.main
          key={pathname}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="flex-grow"
        >
          {children}
        </motion.main>
      </AnimatePresence>
    </div>
  );
}
