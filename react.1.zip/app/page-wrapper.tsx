
'use client';

import { ThemeProvider } from '@/components/theme-provider';

export default function PageWrapper({
  children,
}: {
  children: React.ReactNode;
}) {

  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
      themes={['light', 'dark', 'theme-blue', 'theme-green', 'theme-purple', 'theme-red', 'theme-orange', 'theme-slate', 'theme-rose']}
    >
      {children}
    </ThemeProvider>
  );
}
