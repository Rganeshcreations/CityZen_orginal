
'use client';

import { Building2 } from 'lucide-react';
import { MotionDiv } from '@/components/shared/motion-div';
import { useRef } from 'react';

export function SplashScreen() {
    const ref = useRef<HTMLDivElement>(null);

    return (
        <div ref={ref} className="fixed inset-0 z-50 flex items-center justify-center bg-black">
            <video
                autoPlay
                loop
                muted
                playsInline
                className="absolute inset-0 w-full h-full object-cover"
                src="https://storage.googleapis.com/static.aiforge.run/splash-video.mp4"
            >
                Your browser does not support the video tag.
            </video>
            <MotionDiv
                className="relative z-10 flex flex-col items-center gap-4 p-6 rounded-2xl bg-black/40 backdrop-blur-md shadow-2xl"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{
                    type: 'spring',
                    stiffness: 100,
                    damping: 10,
                    restDelta: 0.001,
                    scale: {
                        type: 'spring',
                        damping: 5,
                        stiffness: 100,
                        restDelta: 0.001
                    }
                }}
            >
                 <MotionDiv
                    animate={{
                        scale: [1, 1.05, 1],
                    }}
                    transition={{
                        duration: 2,
                        ease: "easeInOut",
                        repeat: Infinity,
                        repeatType: "loop",
                    }}
                >
                    <Building2 className="h-16 w-16 text-white drop-shadow-lg" />
                </MotionDiv>
                <MotionDiv
                    whileHover={{ scale: 1.1 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                >
                    <span className="text-4xl font-bold text-white tracking-wider drop-shadow-lg">CitySphere</span>
                </MotionDiv>
            </MotionDiv>
        </div>
    );
}
