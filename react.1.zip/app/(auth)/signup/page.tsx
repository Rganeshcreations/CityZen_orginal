
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Building2, Loader2 } from 'lucide-react';
import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/firebase';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { sendOtp } from '@/ai/flows/send-otp-flow';

const formSchema = z.object({
  name: z.string().min(3, { message: 'Name must be at least 3 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }),
  password: z.string().min(8, { message: 'Password must be at least 8 characters.' }),
});

type SignupFormValues = z.infer<typeof formSchema>;

export default function SignupPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const auth = useAuth();
  const router = useRouter();

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: '', email: '', password: '' },
  });

  async function onSubmit(values: SignupFormValues) {
    setLoading(true);

    if (!auth) {
        toast({
            variant: 'destructive',
            title: 'Authentication Error',
            description: 'Firebase is not configured. Please try again later.',
        });
        setLoading(false);
        return;
    }

    try {
      // 1. Create the user in Firebase Auth.
      const userCredential = await createUserWithEmailAndPassword(auth, values.email, values.password);
      const user = userCredential.user;

      // 2. Update the user's profile with their name.
      await updateProfile(user, { displayName: values.name });

      // 3. Send the OTP email and get the OTP back.
      const { otp } = await sendOtp({ email: values.email });
      
      // 4. Store the OTP and user details in session storage for the verification/role selection pages.
      sessionStorage.setItem('otp-for-verification', otp);
      sessionStorage.setItem('new-user-name', values.name);
      sessionStorage.setItem('new-user-email', values.email);

      toast({
        title: 'Verification Required',
        description: 'A verification code has been sent to your email.',
      });
      
      // 5. Redirect to the OTP verification page. The user remains logged in.
      router.push(`/verify-otp?email=${encodeURIComponent(values.email)}`);

    } catch (error: any) {
        console.error('Signup error:', error);
        let description = 'An unexpected error occurred. Please try again.';
        if (error.code === 'auth/email-already-in-use') {
          description = 'This email is already registered. Please sign in instead.';
        }
        toast({
          variant: 'destructive',
          title: 'Signup Failed',
          description,
        });
    } finally {
        setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center animated-gradient p-4">
      <div className="w-full max-w-md space-y-8 rounded-2xl bg-background/80 p-8 shadow-2xl backdrop-blur-sm">
        <div className="text-center">
          <div className="mb-4 flex justify-center">
            <Building2 className="h-12 w-12 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Create an Account</h1>
          <p className="text-muted-foreground">
            Enter your details to create a new account.
          </p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
             <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="you@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="••••••••" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create Account
            </Button>
          </form>
        </Form>
         <p className="text-center text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link
              href="/login"
              className="font-medium text-primary hover:underline"
            >
              Sign in
            </Link>
          </p>
      </div>
    </div>
  );
}
