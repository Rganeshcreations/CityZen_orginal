
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useToast } from '@/hooks/use-toast';
import { Building2, Loader2 } from 'lucide-react';
import { useState, Suspense, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth, useFirestore } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { verifyOtp } from '@/ai/flows/verify-otp-flow';


const FormSchema = z.object({
  pin: z.string().min(6, {
    message: 'Your one-time password must be 6 characters.',
  }),
});

function VerifyOtpForm() {
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get('email');
  const [loading, setLoading] = useState(false);
  const auth = useAuth();
  const firestore = useFirestore();

  useEffect(() => {
    // This effect ensures we redirect if the email is missing on mount.
    const otp = sessionStorage.getItem('otp-for-verification');
    if (!otp || !email) {
      toast({
        variant: 'destructive',
        title: 'Invalid Session',
        description: 'Verification details are missing. Please sign up again.',
      });
      router.push('/signup');
    }
  }, [email, router, toast]);


  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      pin: '',
    },
  });

  async function onSubmit(data: z.infer<typeof FormSchema>) {
    setLoading(true);

    const storedOtp = sessionStorage.getItem('otp-for-verification');

    if (!email || !storedOtp || !auth?.currentUser || !firestore) {
      toast({
        variant: 'destructive',
        title: 'Session Expired or System Error',
        description: 'Verification details are missing or services are unavailable. Please sign up again.',
      });
      setLoading(false);
      router.push('/signup');
      return;
    }

    try {
      // Client-side verification, reading directly from sessionStorage
      if (data.pin === storedOtp) {
        // Call the server flow as a formality or for logging
        await verifyOtp({ otp: data.pin, email });

        // --- Create user profile directly ---
        const currentUser = auth.currentUser;
        const userDocRef = doc(firestore, 'users', currentUser.uid);
        const userProfile = {
            uid: currentUser.uid,
            name: currentUser.displayName || sessionStorage.getItem('new-user-name') || 'N/A',
            email: currentUser.email!,
            role: 'user', // Set role automatically
        };

        await setDoc(userDocRef, userProfile);

        // --- Cleanup and Redirect ---
        sessionStorage.removeItem('otp-for-verification');
        sessionStorage.removeItem('new-user-name');
        sessionStorage.removeItem('new-user-email');
        
        toast({
          title: 'Verification Successful!',
          description: "Welcome to CitySphere!",
        });

        // Redirect to the main dashboard
        router.push('/dashboard');

      } else {
        throw new Error('Invalid OTP. Please try again.');
      }
    } catch (error: any) {
       if (error.name === 'FirestorePermissionError') {
          errorEmitter.emit('permission-error', error);
          toast({
            variant: 'destructive',
            title: 'Setup Failed',
            description: 'Could not save your profile due to a permissions issue.',
          });
       } else {
         toast({
            variant: 'destructive',
            title: 'Verification Failed',
            description: error.message || 'An unexpected error occurred.',
        });
       }
    } finally {
      setLoading(false);
    }
  }

  if (!email) {
    // This happens before the useEffect can redirect, providing instant feedback.
    return (
      <div className="text-center text-destructive">
        <p>Email parameter is missing. Please go back to the signup page.</p>
        <Button onClick={() => router.push('/signup')} className="mt-4">Back to Signup</Button>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md space-y-8 rounded-2xl bg-background/80 p-8 shadow-2xl backdrop-blur-sm">
        <div className="text-center">
            <div className="mb-4 flex justify-center">
                <Building2 className="h-12 w-12 text-primary" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Check your email</h1>
            <p className="text-muted-foreground">
                We&apos;ve sent a 6-digit verification code to <span className="font-semibold text-primary">{email}</span>.
            </p>
        </div>

        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                control={form.control}
                name="pin"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>One-Time Password</FormLabel>
                    <FormControl>
                        <InputOTP maxLength={6} {...field}>
                        <InputOTPGroup>
                            <InputOTPSlot index={0} />
                            <InputOTPSlot index={1} />
                            <InputOTPSlot index={2} />
                            <InputOTPSlot index={3} />
                            <InputOTPSlot index={4} />
                            <InputOTPSlot index={5} />
                        </InputOTPGroup>
                        </InputOTP>
                    </FormControl>
                    <FormDescription>
                        Please enter the one-time password sent to your email.
                    </FormDescription>
                    <FormMessage />
                    </FormItem>
                )}
                />
                
                <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Verify Account
                </Button>
            </form>
        </Form>
    </div>
  );
}


export default function VerifyOtpPage() {
    return (
        <div className="flex min-h-screen items-center justify-center animated-gradient p-4">
           <Suspense fallback={<Loader2 className="h-12 w-12 animate-spin text-primary" />}>
                <VerifyOtpForm />
            </Suspense>
        </div>
    )
}
