
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useToast } from '@/hooks/use-toast';
import { Building2, Loader2, ShieldCheck } from 'lucide-react';
import { useState, useEffect, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { updateUserPassword } from './actions';

const FormSchema = z.object({
  pin: z.string().min(6, { message: 'Your one-time password must be 6 characters.' }),
  newPassword: z.string().min(8, { message: 'Password must be at least 8 characters.' }),
  confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
});


function ResetPasswordForm() {
  const { toast } = useToast();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // State to hold values from sessionStorage and check if loading is complete
  const [retrievedEmail, setRetrievedEmail] = useState<string | null>(null);
  const [storedOtp, setStoredOtp] = useState<string | null>(null);
  const [sessionCheckComplete, setSessionCheckComplete] = useState(false);


  useEffect(() => {
    // This code now runs only on the client, after the component has mounted.
    const email = sessionStorage.getItem('reset-email');
    const otp = sessionStorage.getItem('reset-otp');
    
    if (!email || !otp) {
        toast({
            variant: 'destructive',
            title: 'Invalid Session',
            description: 'Could not find reset information. Please start over.',
        });
        router.push('/forgot-password');
    } else {
        setRetrievedEmail(email);
        setStoredOtp(otp);
    }
    setSessionCheckComplete(true);
  }, [router, toast]);


  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: { pin: '', newPassword: '', confirmPassword: '' },
  });

  async function onSubmit(data: z.infer<typeof FormSchema>) {
    setLoading(true);

    if (!retrievedEmail || !storedOtp) {
        toast({
            variant: 'destructive',
            title: 'Session Expired',
            description: 'Your password reset session has expired. Please try again.',
        });
        router.push('/forgot-password');
        setLoading(false);
        return;
    }

    // 1. Verify OTP on the client-side first
    if (data.pin !== storedOtp) {
        toast({
            variant: 'destructive',
            title: 'Invalid OTP',
            description: 'The verification code you entered is incorrect. Please try again.',
        });
        setLoading(false);
        return;
    }

    try {
        // 2. If OTP is correct, call the server action to update the password
        const result = await updateUserPassword(retrievedEmail, data.newPassword);
        
        if (result.success) {
             // Clear the session storage
            sessionStorage.removeItem('reset-email');
            sessionStorage.removeItem('reset-otp');
            setSuccess(true);
        } else {
            throw new Error(result.error || 'An unexpected error occurred.');
        }

    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Password Reset Failed',
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }
  
  if (success) {
    return (
        <div className="w-full max-w-md space-y-8 rounded-2xl bg-background/80 p-8 text-center shadow-2xl backdrop-blur-sm">
          <div className="mb-4 flex justify-center">
            <ShieldCheck className="h-16 w-16 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Password Reset Successfully!</h1>
          <p className="text-muted-foreground">
            You can now sign in with your new password.
          </p>
           <Button onClick={() => router.push('/login')}>
                Back to Sign In
          </Button>
        </div>
    );
  }
  
  if (!sessionCheckComplete) {
    return <Loader2 className="h-12 w-12 animate-spin text-primary" />;
  }

  return (
    <div className="w-full max-w-md space-y-8 rounded-2xl bg-background/80 p-8 shadow-2xl backdrop-blur-sm">
        <div className="text-center">
            <div className="mb-4 flex justify-center">
                <Building2 className="h-12 w-12 text-primary" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Create New Password</h1>
            <p className="text-muted-foreground">
                We&apos;ve sent a 6-digit code to <span className="font-semibold text-primary">{retrievedEmail || 'your email'}</span>.
            </p>
        </div>

        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                    control={form.control}
                    name="pin"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>One-Time Password</FormLabel>
                        <FormControl>
                            <InputOTP maxLength={6} {...field}>
                            <InputOTPGroup>
                                <InputOTPSlot index={0} /><InputOTPSlot index={1} /><InputOTPSlot index={2} />
                                <InputOTPSlot index={3} /><InputOTPSlot index={4} /><InputOTPSlot index={5} />
                            </InputOTPGroup>
                            </InputOTP>
                        </FormControl>
                        <FormDescription>Enter the code sent to your email.</FormDescription>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="newPassword"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>New Password</FormLabel>
                        <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Confirm New Password</FormLabel>
                        <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                
                <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Reset Password
                </Button>
            </form>
        </Form>
    </div>
  );
}


export default function ResetPasswordPage() {
    return (
        <div className="flex min-h-screen items-center justify-center animated-gradient p-4">
           <Suspense fallback={<Loader2 className="h-12 w-12 animate-spin text-primary" />}>
                <ResetPasswordForm />
            </Suspense>
        </div>
    )
}
