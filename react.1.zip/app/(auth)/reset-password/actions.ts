
'use server';

import { getAdminApp } from '@/lib/firebase-admin';
import * as admin from 'firebase-admin';

export async function updateUserPassword(email: string, newPassword: string): Promise<{ success: boolean, error?: string }> {
  try {
    const adminApp = getAdminApp();
    if (!adminApp) {
      throw new Error('SERVER_CONFIG_ERROR');
    }

    const user = await admin.auth(adminApp).getUserByEmail(email);
    
    if (!user) {
        throw new Error('USER_NOT_FOUND');
    }

    await admin.auth(adminApp).updateUser(user.uid, {
      password: newPassword,
    });

    return { success: true };

  } catch (error: any) {
    console.error('Error updating password:', error);

    let errorMessage = 'An unexpected error occurred while updating the password.';
    if (error.message === 'SERVER_CONFIG_ERROR') {
        errorMessage = 'The server is not configured correctly to update passwords. Please contact support.';
    } else if (error.code === 'auth/user-not-found' || error.message === 'USER_NOT_FOUND') {
        errorMessage = 'No user account was found for this email address.';
    } else if (error.code === 'auth/invalid-password') {
        errorMessage = 'The new password is not valid. It must be at least 6 characters long.';
    }

    return { success: false, error: errorMessage };
  }
}
