
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const fromLat = searchParams.get('fromLat');
  const fromLng = searchParams.get('fromLng');
  const toLat = searchParams.get('toLat');
  const toLng = searchParams.get('toLng');

  if (!fromLat || !fromLng || !toLat || !toLng) {
    return NextResponse.json({ error: 'Missing start or end coordinates' }, { status: 400 });
  }

  // Request alternative routes from the OSRM API
  const url = `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson&alternatives=true`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      const errorData = await response.json();
      console.error('OSRM API Error:', errorData);
      return NextResponse.json({ error: errorData.message || `OSRM API failed with status ${response.status}` }, { status: response.status });
    }
    const data = await response.json();
    if (data.routes && data.routes.length > 0) {
      // Return all found routes
      return NextResponse.json(data.routes);
    } else {
      return NextResponse.json({ error: 'No route found' }, { status: 404 });
    }
  } catch (error) {
    console.error('Error fetching route from OSRM API:', error);
    return NextResponse.json({ error: 'Internal server error while fetching route' }, { status: 500 });
  }
}
