
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const address = searchParams.get('address');
  
  if (!address) {
    return NextResponse.json({ error: 'Address parameter is required' }, { status: 400 });
  }

  // Using Nominatim for geocoding, which doesn't require an API key for most use cases.
  // See https://operations.osmfoundation.org/policies/nominatim/ for usage policy.
  const geoUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`;

  try {
    const geoResponse = await fetch(geoUrl, {
      headers: {
        // It's good practice and often required to provide a specific User-Agent.
        'User-Agent': 'CitySphereApp/1.0 (Firebase App Prototyping)'
      }
    });
    
    if (!geoResponse.ok) {
      const errorData = await geoResponse.text();
      console.error('Nominatim Geocoding API error:', errorData);
      return NextResponse.json({ error: `Failed to geocode location. Status: ${geoResponse.status}` }, { status: geoResponse.status });
    }

    const data = await geoResponse.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('Geocoding fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch from geocoding API' }, { status: 500 });
  }
}
