
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// Define a schema for the incoming request body to ensure type safety.
const PriceComparisonRequestSchema = z.discriminatedUnion('category', [
    z.object({ category: z.literal('Travel'), from: z.string(), to: z.string(), date: z.string(), mode: z.string() }),
    z.object({ category: z.literal('Local'), city: z.string(), from: z.string(), to: z.string() }),
    z.object({ category: z.literal('Food'), location: z.string(), cuisine: z.string() }),
]);

// --- Mock Data Generators ---

const generateMockFlights = (request: any) => {
  const providers = [
    { name: 'IndiGo', url: 'https://www.goindigo.in' },
    { name: 'Vistara', url: 'https://www.airvistara.com' },
    { name: 'Air India', url: 'https://www.airindia.com' }
  ];
  return providers.map((provider, index) => ({
    category: 'Travel' as const, type: 'Flight' as const,
    provider: provider.name,
    details: `${request.from.toUpperCase()} to ${request.to.toUpperCase()} - Flight ${Math.floor(1000 + Math.random() * 9000)}`,
    price: 4500 + index * 500 + Math.floor(Math.random() * 500),
    bookingUrl: provider.url,
    rating: parseFloat((4.2 + Math.random() * 0.7).toFixed(1)),
    duration: `${2 + index}h ${Math.floor(Math.random() * 60)}m`,
  }));
};

const generateMockBuses = (request: any) => {
  const providers = [
    { name: 'RedBus', url: 'https://www.redbus.in' },
    { name: 'AbhiBus', url: 'https://www.abhibus.com' },
    { name: 'IntrCity SmartBus', url: 'https://www.intrcity.com' }
  ];
  return providers.map((provider, index) => ({
    category: 'Travel'as const, type: 'Bus' as const,
    provider: provider.name,
    details: `Sleeper A/C from ${request.from} to ${request.to}`,
    price: 800 + index * 100 + Math.floor(Math.random() * 100),
    bookingUrl: provider.url,
    rating: parseFloat((4.0 + Math.random() * 0.8).toFixed(1)),
    duration: `${8 + index}h ${Math.floor(Math.random() * 60)}m`,
  }));
};

const generateMockTrains = (request: any) => {
  const providers = [
    { name: 'IRCTC', url: 'https://www.irctc.co.in' },
    { name: 'RailYatri', url: 'https://www.railyatri.in' }
  ];
  return providers.map((provider, index) => ({
    category: 'Travel' as const, type: 'Train' as const,
    provider: provider.name,
    details: `3A Class from ${request.from} to ${request.to}`,
    price: 600 + index * 150 + Math.floor(Math.random() * 100),
    bookingUrl: provider.url,
    rating: parseFloat((4.1 + Math.random() * 0.5).toFixed(1)),
    duration: `${7 + index}h ${Math.floor(Math.random() * 60)}m`,
  }));
};

const generateMockShips = (request: any) => {
    const providers = [
        { name: 'Angriya Cruises', url: 'https://angriyacruises.com' },
        { name: 'Cordelia Cruises', url: 'https://cordeliacruises.com' }
    ];
    return providers.map((provider, index) => ({
        category: 'Travel' as const, type: 'Ship' as const,
        provider: provider.name,
        details: `Luxury Cruise from ${request.from} to ${request.to}`,
        price: 8000 + index * 1000 + Math.floor(Math.random() * 500),
        bookingUrl: provider.url,
        rating: parseFloat((4.5 + Math.random() * 0.4).toFixed(1)),
        duration: `${24 + index * 4}h`,
    }));
};

const generateMockLocalTransport = (request: any) => {
  const providers = [
    { name: 'Uber', url: 'https://www.uber.com/in/en/' },
    { name: 'Ola', url: 'https://www.olacabs.com' },
    { name: 'Rapido Auto', url: 'https://www.rapido.bike' }
  ];
  return providers.map((provider, index) => ({
    category: 'Local' as const, type: 'Car' as const,
    provider: provider.name,
    details: provider.name === 'Rapido Auto' ? `Auto Rickshaw in ${request.city}` : (index % 2 === 0 ? `Sedan in ${request.city}` : `Hatchback in ${request.city}`),
    price: 150 + index * 30 + Math.floor(Math.random() * 50),
    bookingUrl: provider.url,
    rating: parseFloat((4.3 + Math.random() * 0.6).toFixed(1)),
    eta: `${5 + index * 2} mins`,
  }));
};

const generateMockFoodDelivery = (request: any) => {
  const providers = [
    { name: 'Zomato', url: 'https://www.zomato.com' },
    { name: 'Swiggy', url: 'https://www.swiggy.com' }
  ];
  return providers.map((provider, index) => ({
    category: 'Food' as const, type: 'Food' as const,
    provider: provider.name,
    details: `Best ${request.cuisine} restaurants near ${request.location}`,
    price: 350 + index * 50 + Math.floor(Math.random() * 100),
    bookingUrl: provider.url,
    rating: parseFloat((4.0 + Math.random() * 0.9).toFixed(1)),
    deliveryTime: `${25 + index * 5} mins`,
  }));
};


// --- Main API Handler ---

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsedRequest = PriceComparisonRequestSchema.safeParse(body);

    if (!parsedRequest.success) {
      return NextResponse.json({ error: 'Invalid request body', details: parsedRequest.error.flatten() }, { status: 400 });
    }
    
    const data = parsedRequest.data;
    let results: any[] = [];

    console.log(`[Mock API Route] Received request for category: ${data.category}`);

    switch (data.category) {
      case 'Travel':
        switch(data.mode) {
            case 'Flight':
                results = generateMockFlights(data);
                break;
            case 'Bus':
                results = generateMockBuses(data);
                break;
            case 'Train':
                results = generateMockTrains(data);
                break;
            case 'Ship':
                results = generateMockShips(data);
                break;
            default:
                results = [];
        }
        break;
      case 'Local':
        results = generateMockLocalTransport(data);
        break;
      case 'Food':
        results = generateMockFoodDelivery(data);
        break;
      default:
        return NextResponse.json({ error: 'Invalid category specified' }, { status: 400 });
    }

    results.sort((a, b) => a.price - b.price);

    return NextResponse.json({ results });

  } catch (error) {
    console.error('[Mock API Route] Error processing request:', error);
    if (error instanceof Error) {
        return NextResponse.json({ error: 'An unexpected error occurred.', details: error.message }, { status: 500 });
    }
    return NextResponse.json({ error: 'An unexpected error occurred.' }, { status: 500 });
  }
}
