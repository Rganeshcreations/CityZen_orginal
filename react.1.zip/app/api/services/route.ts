
import { NextResponse } from 'next/server';
import { workerData } from '@/data/worker-data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  
  const city = searchParams.get('city');
  const job = searchParams.get('job');
  const getCities = searchParams.get('cities');
  const getJobs = searchParams.get('jobs');

  if (getCities) {
    const cities = Object.keys(workerData).sort();
    return NextResponse.json({ cities });
  }

  if (city && getJobs) {
    const cityData = workerData[city as keyof typeof workerData];
    if (cityData) {
      const jobs = Object.keys(cityData).sort();
      return NextResponse.json({ jobs });
    }
    return NextResponse.json({ error: `City '${city}' not found.` }, { status: 404 });
  }

  if (city && job) {
    const cityData = workerData[city as keyof typeof workerData];
    if (cityData) {
      const jobData = cityData[job as keyof typeof cityData] || [];
      return NextResponse.json({ workers: jobData });
    }
    return NextResponse.json({ error: `City '${city}' not found.` }, { status: 404 });
  }

  return NextResponse.json({ error: 'Invalid query parameters. Use ?cities=true, ?city=<city>&jobs=true, or ?city=<city>&job=<job>.' }, { status: 400 });
}
