
import { NextResponse } from 'next/server';
import { cityData } from '@/data/tourist-data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const city = searchParams.get('city');

  if (!city) {
    return NextResponse.json({ error: 'City query parameter is required.' }, { status: 400 });
  }
  
  const normalizedCity = Object.keys(cityData).find(
    key => key.toLowerCase() === city.toLowerCase().trim()
  ) as keyof typeof cityData | undefined;

  if (normalizedCity && cityData[normalizedCity]) {
    return NextResponse.json({ places: cityData[normalizedCity] });
  }

  return NextResponse.json({ error: `No data found for city: ${city}` }, { status: 404 });
}
