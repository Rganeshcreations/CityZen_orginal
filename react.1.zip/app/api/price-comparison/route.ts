
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { format } from 'date-fns';

// Define a schema for the incoming request body to ensure type safety.
const PriceComparisonRequestSchema = z.discriminatedUnion('category', [
    z.object({ category: z.literal('Travel'), from: z.string(), to: z.string(), date: z.string(), mode: z.string() }),
    z.object({ category: z.literal('Local'), from: z.string(), to: z.string() }),
    z.object({ category: z.literal('Food'), location: z.string(), cuisine: z.string() }),
]);

// --- Geocoding Helper ---
const geocode = async (address: string) => {
    // This uses the internal geocoding API route. Make sure the server is running.
    const host = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'http://localhost:9002';
    const url = `${host}/api/geocode?address=${encodeURIComponent(address)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Geocoding failed for ${address}`);
    const data = await res.json();
    if (data && data.length > 0) {
        return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
    }
    throw new Error(`No coordinates found for ${address}`);
};


// --- Mock Data Generators & API Fetchers ---

const generateMockTravelData = (request: any) => {
    const providers = {
        Bus: ['RedBus', 'AbhiBus', 'IntrCity SmartBus'],
        Train: ['IRCTC', 'RailYatri'],
        Ship: ['Angriya Cruises', 'Cordelia Cruises']
    };

    if (!providers[request.mode as keyof typeof providers]) {
        return [];
    }

    return providers[request.mode as keyof typeof providers].map((provider, index) => {
        const basePrice = request.mode === 'Bus' ? 800 : request.mode === 'Train' ? 500 : 4500;
        const durationHours = request.mode === 'Bus' ? 12 : request.mode === 'Train' ? 10 : 48;
        
        return {
            category: 'Travel' as const,
            type: request.mode as 'Bus' | 'Train' | 'Ship',
            provider,
            details: `${request.from} to ${request.to}`,
            price: basePrice + (index * 50) + Math.floor(Math.random() * 100),
            bookingUrl: `https://www.${provider.toLowerCase().replace(/\s/g, '')}.com`,
            rating: parseFloat((4.0 + Math.random()).toFixed(1)),
            duration: `${durationHours + index}h ${Math.floor(Math.random() * 60)}m`,
        };
    });
};


const fetchFromAgoda = async (request: any) => {
    const apiKey = process.env.AGODA_RAPIDAPI_KEY;
    if (!apiKey) {
        console.warn('[API Route] Agoda API key not found. Skipping.');
        return [];
    }
    
    const host = 'agoda-com.p.rapidapi.com';

    try {
        // Step 1: Get location ID for the destination city
        const locationUrl = `https://agoda-com.p.rapidapi.com/locations/auto-complete?query=${encodeURIComponent(request.to)}`;
        const locationResponse = await fetch(locationUrl, {
            method: 'GET',
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': host },
        });

        if (!locationResponse.ok) throw new Error(`Agoda location API failed with status ${locationResponse.status}`);
        
        const locationData = await locationResponse.json();
        const cityId = locationData.resolvedLocations[0]?.cityId;
        
        if (!cityId) throw new Error('Could not find city ID for the destination.');

        // Step 2: Search for hotels using the city ID
        const checkinDate = format(new Date(request.date), 'yyyy-MM-dd');
        const searchUrl = `https://agoda-com.p.rapidapi.com/hotels/search-by-city?cityId=${cityId}&checkin=${checkinDate}&locale=en-us&currency=INR&nights=1&adults=2&pageSize=5`;

        const searchResponse = await fetch(searchUrl, {
            method: 'GET',
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': host },
        });
        
        if (!searchResponse.ok) throw new Error(`Agoda search API failed with status ${searchResponse.status}`);
        
        const searchData = await searchResponse.json();
        
        // Step 3: Normalize the data
        return searchData.results.map((hotel: any) => ({
            category: 'Travel' as const,
            type: 'Hotel' as const,
            provider: 'Agoda', // The provider is Agoda
            details: hotel.hotelName,
            price: hotel.price.display,
            bookingUrl: 'https://www.agoda.com',
            rating: hotel.ratings.value,
            duration: '1 night', // Based on our search params
        }));

    } catch (error) {
        console.error('Failed to fetch from Agoda API:', error);
        return [];
    }
};

const fetchFromTripadvisorForTravel = async (request: any) => {
    const apiKey = process.env.TRIPADVISOR_RAPIDAPI_KEY;
    if (!apiKey) {
        console.warn('[API Route] Tripadvisor API key not found. Skipping.');
        return [];
    }

    try {
        // Step 1: Get Location ID
        const locationSearchUrl = `https://tripadvisor16.p.rapidapi.com/api/v1/flights/searchLocation?query=${encodeURIComponent(request.to)}`;
        const locationResponse = await fetch(locationSearchUrl, {
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': 'tripadvisor16.p.rapidapi.com' }
        });
        if (!locationResponse.ok) throw new Error('Tripadvisor location search failed');
        const locationData = await locationResponse.json();
        const locationId = locationData.data[0]?.locationId;
        if (!locationId) throw new Error('Could not find location ID in Tripadvisor');
        
        // Step 2: Search Hotels by Location ID
        const searchUrl = `https://tripadvisor16.p.rapidapi.com/api/v1/hotels/searchHotelsByLocation?locationId=${locationId}&checkIn=${format(new Date(request.date), 'yyyy-MM-dd')}&checkOut=${format(new Date(new Date(request.date).getTime() + 86400000), 'yyyy-MM-dd')}&adults=1&rooms=1&currency=INR&limit=5`;
        const searchResponse = await fetch(searchUrl, {
             headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': 'tripadvisor16.p.rapidapi.com' }
        });
        if (!searchResponse.ok) throw new Error('Tripadvisor hotel search failed');
        const searchData = await searchResponse.json();

        // Step 3: Normalize data
        return searchData.data.data.map((hotel: any) => ({
             category: 'Travel' as const,
            type: 'Hotel' as const,
            provider: 'Tripadvisor',
            details: hotel.title,
            price: parseFloat(hotel.priceForDisplay?.replace(/[^0-9.]/g, '')) || 0,
            bookingUrl: 'https://www.tripadvisor.com',
            rating: hotel.rating,
            duration: '1 night',
        }));

    } catch(error) {
        console.error('Failed to fetch from Tripadvisor for travel:', error);
        return [];
    }
};

const fetchFromBookingForTravel = async (request: any) => {
    const apiKey = process.env.BOOKING_RAPIDAPI_KEY;
    if (!apiKey) {
        console.warn('[API Route] Booking.com API key not found. Skipping.');
        return [];
    }
    const host = 'booking-com15.p.rapidapi.com';

    try {
        // Step 1: Get destination ID
        const destUrl = `https://booking-com15.p.rapidapi.com/api/v1/hotels/searchDestination?query=${encodeURIComponent(request.to)}`;
        const destResponse = await fetch(destUrl, {
            method: 'GET',
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': host },
        });
        if (!destResponse.ok) throw new Error('Booking.com destination search failed');
        const destData = await destResponse.json();
        const destId = destData.data[0]?.dest_id;
        const destType = destData.data[0]?.dest_type;

        if (!destId || !destType) throw new Error('Could not find destination ID in Booking.com');

        // Step 2: Search hotels
        const searchUrl = new URL('https://booking-com15.p.rapidapi.com/api/v1/hotels/searchHotels');
        searchUrl.searchParams.set('dest_id', destId);
        searchUrl.searchParams.set('dest_type', destType);
        searchUrl.searchParams.set('arrival_date', format(new Date(request.date), 'yyyy-MM-dd'));
        searchUrl.searchParams.set('departure_date', format(new Date(new Date(request.date).getTime() + 86400000), 'yyyy-MM-dd'));
        searchUrl.searchParams.set('currency_code', 'INR');
        searchUrl.searchParams.set('adults', '1');
        searchUrl.searchParams.set('room_qty', '1');
        searchUrl.searchParams.set('page_number', '1');
        searchUrl.searchParams.set('language_code', 'en-us');

        const searchResponse = await fetch(searchUrl.toString(), {
            method: 'GET',
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': host },
        });
        if (!searchResponse.ok) throw new Error('Booking.com hotel search failed');
        const searchData = await searchResponse.json();

        // Step 3: Normalize data
        return searchData.data.hotels.map((hotel: any) => ({
            category: 'Travel' as const,
            type: 'Hotel' as const,
            provider: 'Booking.com',
            details: hotel.property.name,
            price: hotel.property.priceBreakdown.grossPrice.value,
            bookingUrl: 'https://www.booking.com',
            rating: hotel.property.reviewScore,
            duration: '1 night',
        }));

    } catch (error) {
        console.error('Failed to fetch from Booking.com for travel:', error);
        return [];
    }
};

const fetchFromKiwi = async (request: any) => {
    const apiKey = process.env.KIWI_RAPIDAPI_KEY;
    if (!apiKey) {
      console.warn('[API Route] Kiwi.com API key not found. Skipping.');
      return [];
    }

    const host = 'kiwi-com-cheap-flights.p.rapidapi.com';
    
    const searchDate = new Date(request.date);

    const url = new URL(`https://${host}/v2/search`);
    url.searchParams.set('fly_from', `airport:${request.from}`);
    url.searchParams.set('fly_to', `airport:${request.to}`);
    url.searchParams.set('date_from', format(searchDate, 'dd/MM/yyyy'));
    url.searchParams.set('date_to', format(searchDate, 'dd/MM/yyyy'));
    url.searchParams.set('curr', 'INR');
    url.searchParams.set('limit', '5'); // Limit to 5 results

    try {
        const response = await fetch(url.toString(), {
            method: 'GET',
            headers: {
                'x-rapidapi-key': apiKey,
                'x-rapidapi-host': host
            }
        });
        
        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Kiwi.com API failed. Status: ${response.status}, Body: ${errorBody}`);
        }

        const data = await response.json();
        
        if (!data.data || data.data.length === 0) return [];
        
        return data.data.slice(0, 5).map((flight: any) => {
            const provider = flight.airlines.map((a: string) => flight.airline_map[a]).join(', ');
            return {
                category: 'Travel' as const,
                type: 'Flight' as const,
                provider,
                details: `From ${flight.cityFrom} to ${flight.cityTo}`,
                price: flight.price,
                bookingUrl: flight.deep_link, // Kiwi provides a deep link which is better here
                rating: undefined,
                duration: `${Math.floor(flight.duration.total / 3600)}h ${Math.floor((flight.duration.total % 3600) / 60)}m`,
            };
        });

    } catch (error) {
        console.error('Failed to fetch from Kiwi.com API:', error);
        return [];
    }
};


const generateTravelDataFromApi = async (request: any) => {
    
    if (request.mode === 'Flight') {
        console.log('[API Route] Fetching flight data from Kiwi.com API.');
        return await fetchFromKiwi(request);
    }

    if (['Bus', 'Train', 'Ship'].includes(request.mode)) {
        console.log(`[API Route] Generating mock data for ${request.mode}.`);
        return generateMockTravelData(request);
    }
    
    // For other modes or if mode is not specified, treat as hotel search as a fallback
    console.log('[API Route] Defaulting to hotel search. Fetching data from Agoda, Tripadvisor, and Booking.com.');
    const [agodaResults, tripadvisorResults, bookingResults] = await Promise.allSettled([
        fetchFromAgoda(request),
        fetchFromTripadvisorForTravel(request),
        fetchFromBookingForTravel(request),
    ]);

    const combinedResults = [
        ...(agodaResults.status === 'fulfilled' ? agodaResults.value : []),
        ...(tripadvisorResults.status === 'fulfilled' ? tripadvisorResults.value : []),
        ...(bookingResults.status === 'fulfilled' ? bookingResults.value : []),
    ];

    // Since we are fetching hotels, update the type
    return combinedResults.map(res => ({...res, type: 'Hotel'}));
};

const fetchFromBookingForLocal = async (fromCoords: { lat: number; lng: number; }, toCoords: { lat: number; lng: number; }) => {
    const apiKey = process.env.BOOKING_RAPIDAPI_KEY;
    if (!apiKey) {
      console.warn('[API Route] Booking.com API key not found for local transport. Skipping.');
      return [];
    }

    try {
        const apiUrl = new URL('https://booking-com15.p.rapidapi.com/api/v1/cars/searchCarRentals');
        apiUrl.searchParams.set('pick_up_latitude', fromCoords.lat.toString());
        apiUrl.searchParams.set('pick_up_longitude', fromCoords.lng.toString());
        apiUrl.searchParams.set('drop_off_latitude', toCoords.lat.toString());
        apiUrl.searchParams.set('drop_off_longitude', toCoords.lng.toString());
        apiUrl.searchParams.set('pick_up_time', '10:00'); 
        apiUrl.searchParams.set('drop_off_time', '10:00');
        
        const response = await fetch(apiUrl.toString(), {
            method: 'GET',
            headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': 'booking-com15.p.rapidapi.com' }
        });

        if (!response.ok) {
            throw new Error(`Booking.com API error: ${response.status}`);
        }

        const data = await response.json();
        return data.data.search_results.map((car: any) => ({
            category: 'Local' as const, type: 'Car' as const,
            provider: car.car_info.supplier_name,
            details: `${car.car_info.make} ${car.car_info.model} or similar`,
            price: parseFloat(car.pricing_info.price),
            bookingUrl: 'https://www.booking.com/cars',
            rating: car.supplier_info.rating ? parseFloat(car.supplier_info.rating) : undefined,
            eta: 'N/A',
        }));
    } catch (error) {
        console.error('Failed to fetch from Booking.com API:', error);
        return [];
    }
};

const fetchFromUber = async (fromCoords: { lat: number; lng: number; }, toCoords: { lat: number; lng: number; }) => {
    const apiKey = process.env.UBER_RAPIDAPI_KEY;
    if (!apiKey) {
      console.warn('[API Route] Uber API key not found. Skipping.');
      return [];
    }

    try {
        const url = `https://uber-com.p.rapidapi.com/price-estimates?start_latitude=${fromCoords.lat}&start_longitude=${fromCoords.lng}&end_latitude=${toCoords.lat}&end_longitude=${toCoords.lng}`;
        const response = await fetch(url, { headers: { 'x-rapidapi-key': apiKey, 'x-rapidapi-host': 'uber-com.p.rapidapi.com' } });
        if (!response.ok) throw new Error(`Uber API error: ${response.status}`);
        const data = await response.json();
        return data.prices.map((ride: any) => ({
            category: 'Local' as const, type: 'Car' as const,
            provider: 'Uber',
            details: ride.display_name,
            price: ride.high_estimate,
            bookingUrl: 'https://www.uber.com',
            rating: undefined,
            eta: `${Math.round(ride.duration / 60)} mins`,
        }));
    } catch (error) {
        console.error('Failed to fetch from Uber API:', error);
        return [];
    }
};


const generateLocalDataFromApi = async (request: { from: string; to: string; }) => {
    try {
        const [fromCoords, toCoords] = await Promise.all([
            geocode(request.from),
            geocode(request.to)
        ]);

        const [bookingResults, uberResults] = await Promise.allSettled([
            fetchFromBookingForLocal(fromCoords, toCoords),
            fetchFromUber(fromCoords, toCoords)
        ]);

        const combinedResults = [
            ...(bookingResults.status === 'fulfilled' ? bookingResults.value : []),
            ...(uberResults.status === 'fulfilled' ? uberResults.value : []),
        ];

        return combinedResults;

    } catch (error) {
        console.error('Failed to geocode for local data:', error);
        return [];
    }
};

const fetchFromTripadvisorForFood = async (request: { cuisine: string; location: string }) => {
    const apiKey = process.env.TRIPADVISOR_RAPIDAPI_KEY;
    if (!apiKey) {
      console.warn('[API Route] Tripadvisor API key not found for food. Skipping.');
      return [];
    }
    
    try {
        const coords = await geocode(request.location);
        const url = `https://tripadvisor16.p.rapidapi.com/api/v1/restaurant/searchRestaurants?latitude=${coords.lat}&longitude=${coords.lng}&searchQuery=${encodeURIComponent(request.cuisine)}`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'x-rapidapi-key': apiKey,
                'x-rapidapi-host': 'tripadvisor16.p.rapidapi.com'
            }
        });
        if (!response.ok) throw new Error(`Tripadvisor API error: ${response.status}`);
        
        const data = await response.json();
        return data.data.map((r: any) => ({
            category: 'Food' as const,
            type: 'Food' as const,
            provider: r.name,
            details: `${r.cuisine.map((c: any) => c.name).join(', ') || request.cuisine} - ${r.priceTag || 'Cost not specified'}`,
            price: parseFloat(r.priceTag?.match(/₹\d+/)?.[0]?.replace('₹', '') || '0') || (Math.floor(Math.random() * 400) + 150),
            bookingUrl: 'https://www.tripadvisor.com',
            rating: r.averageRating,
            deliveryTime: `${Math.floor(Math.random() * 25) + 20} mins`,
        }));
    } catch (error) {
        console.error('Failed to fetch from Tripadvisor API:', error);
        return [];
    }
};

const fetchFromUberEats = async (request: { cuisine: string; location: string }) => {
    const apiKey = process.env.EATER_UBEREATS_RAPIDAPI_KEY;
    if (!apiKey) {
      console.warn('[API Route] Uber Eats API key not found. Skipping.');
      return [];
    }

    try {
        const url = new URL('https://eater-ubereats.p.rapidapi.com/v1/search-eater');
        url.searchParams.set('address', request.location);
        url.searchParams.set('q', request.cuisine);
        url.searchParams.set('country', 'IN');

        const response = await fetch(url.toString(), {
            method: 'GET',
            headers: {
                'x-rapidapi-key': apiKey,
                'x-rapidapi-host': 'eater-ubereats.p.rapidapi.com'
            }
        });

        if (!response.ok) throw new Error(`Uber Eats API error: ${response.status}`);
        
        const data = await response.json();
        if (!data.results) return [];

        return data.results.map((r: any) => ({
            category: 'Food' as const,
            type: 'Food' as const,
            provider: `Uber Eats: ${r.title}`,
            details: `${r.cuisine} - ${r.priceBucket || ''}`,
            price: (r.priceBucket?.length || 0) * 150, // crude price estimation
            bookingUrl: 'https://www.ubereats.com',
            rating: r.rating?.ratingValue,
            deliveryTime: r.etaRange?.text,
        }));
    } catch (error) {
        console.error('Failed to fetch from Uber Eats API:', error);
        return [];
    }
};

const generateFoodDataFromApi = async (request: { cuisine: string; location: string }) => {
    console.log('[API Route] Fetching food data from Tripadvisor and Uber Eats.');

    const [tripadvisorResults, uberEatsResults] = await Promise.allSettled([
        fetchFromTripadvisorForFood(request),
        fetchFromUberEats(request),
    ]);
    
    const combinedResults = [
        ...(tripadvisorResults.status === 'fulfilled' ? tripadvisorResults.value : []),
        ...(uberEatsResults.status === 'fulfilled' ? uberEatsResults.value : []),
    ];

    return combinedResults;
};


// --- Main API Handler ---

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsedRequest = PriceComparisonRequestSchema.safeParse(body);

    if (!parsedRequest.success) {
      return NextResponse.json({ error: 'Invalid request body', details: parsedRequest.error.flatten() }, { status: 400 });
    }
    
    const data = parsedRequest.data;
    let results: any[] = [];

    console.log(`[API Route] Received request for category: ${data.category}`);

    switch (data.category) {
      case 'Travel':
        results = await generateTravelDataFromApi(data);
        break;
      case 'Local':
        results = await generateLocalDataFromApi(data);
        break;
      case 'Food':
        results = await generateFoodDataFromApi(data);
        break;
      default:
        return NextResponse.json({ error: 'Invalid category specified' }, { status: 400 });
    }

    results.sort((a, b) => a.price - b.price);

    return NextResponse.json({ results });

  } catch (error) {
    console.error('[API Route] Error processing request:', error);
    if (error instanceof Error) {
        return NextResponse.json({ error: 'An unexpected error occurred.', details: error.message }, { status: 500 });
    }
    return NextResponse.json({ error: 'An unexpected error occurred.' }, { status: 500 });
  }
}
