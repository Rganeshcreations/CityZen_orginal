
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const lat = searchParams.get('lat');
  const lon = searchParams.get('lon');
  
  if (!lat || !lon) {
    return NextResponse.json({ error: 'Latitude and longitude parameters are required' }, { status: 400 });
  }

  // Using Nominatim for reverse geocoding.
  const geoUrl = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&addressdetails=1`;

  try {
    const geoResponse = await fetch(geoUrl, {
      headers: {
        'User-Agent': `CitySphereApp/1.0 (contact@example.com)`,
        'Accept-Language': 'en-US,en;q=0.9'
      },
      // Add a timeout to prevent long hangs
      signal: AbortSignal.timeout(5000) // 5 seconds
    });
    
    if (!geoResponse.ok) {
      const errorData = await geoResponse.text();
      console.error('Nominatim Reverse Geocoding API error:', errorData);
      return NextResponse.json({ error: `Failed to reverse geocode location. Status: ${geoResponse.status}` }, { status: geoResponse.status });
    }

    const data = await geoResponse.json();
    return NextResponse.json(data);

  } catch (error: any) {
    console.error('Reverse geocoding fetch error:', error.name === 'AbortError' ? 'Request timed out' : error);
    if (error.name === 'AbortError') {
        return NextResponse.json({ error: 'Reverse geocoding service timed out.' }, { status: 504 });
    }
    return NextResponse.json({ error: 'Failed to fetch from reverse geocoding API' }, { status: 500 });
  }
}
