
'use client';

import * as React from 'react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const themes = [
  { name: 'Default', theme: 'light', color: '#319795' }, // Teal
  { name: 'Blue', theme: 'theme-blue', color: '#3b82f6' },
  { name: 'Green', theme: 'theme-green', color: '#22c55e' },
  { name: 'Purple', theme: 'theme-purple', color: '#8b5cf6' },
  { name: 'Red', theme: 'theme-red', color: '#ef4444' },
  { name: 'Orange', theme: 'theme-orange', color: '#f97316' },
  { name: 'Slate', theme: 'theme-slate', color: '#64748b' },
  { name: 'Rose', theme: 'theme-rose', color: '#f43f5e' },
];

export function ThemeSwitcher() {
  const { setTheme } = useTheme();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <span className="text-xl" role="img" aria-label="Artist palette">🎨</span>
          <span className="sr-only">Switch theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {themes.map((themeInfo) => (
          <DropdownMenuItem
            key={themeInfo.theme}
            onClick={() => setTheme(themeInfo.theme)}
            className="flex items-center gap-2 cursor-pointer"
          >
            <div
              className="w-4 h-4 rounded-full border"
              style={{ backgroundColor: themeInfo.color }}
            />
            <span>{themeInfo.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
