
'use client';

import { useEffect, useRef } from 'react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { MapPin } from 'lucide-react';
import { renderToStaticMarkup } from 'react-dom/server';

// Fix for default icon issue with webpack
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface LeafletMapProps {
  center?: { lat: number; lng: number };
  zoom?: number;
  fromLocation?: { lat: number; lng: number } | null;
  toLocation?: { lat: number; lng: number } | null;
  routeGeometries?: any[] | null;
  onMove?: (lat: number, lng: number) => void;
  isDraggable?: boolean;
}

const defaultPosition: L.LatLngTuple = [20.5937, 78.9629];
const defaultZoom = 5;

const routeColors = ['#22c55e', '#f97316', '#a855f7']; // green, orange, purple

export function LeafletMap({
  center,
  zoom = defaultZoom,
  fromLocation,
  toLocation,
  routeGeometries,
  onMove,
  isDraggable = false,
}: LeafletMapProps) {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapRef = useRef<L.Map | null>(null);
    const routeLayersRef = useRef<L.GeoJSON[]>([]);
    const fromMarkerRef = useRef<L.Marker | null>(null);
    const toMarkerRef = useRef<L.Marker | null>(null);
    const draggableMarkerRef = useRef<L.Marker | null>(null);
    
    // Create a custom icon for the draggable marker
    const customIcon = L.divIcon({
        html: renderToStaticMarkup(<MapPin className="text-primary h-10 w-10" fill="currentColor" />),
        className: 'bg-transparent border-none',
        iconSize: [40, 40],
        iconAnchor: [20, 40], // Point of the icon which will correspond to marker's location
    });

    // Initialize map
    useEffect(() => {
        if (mapContainerRef.current && !mapRef.current) {
            const map = L.map(mapContainerRef.current).setView(center ? [center.lat, center.lng] : defaultPosition, center ? 13 : zoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);
            mapRef.current = map;

            if (isDraggable && onMove) {
                 const initialCenter = map.getCenter();
                 draggableMarkerRef.current = L.marker(initialCenter, { draggable: true, icon: customIcon }).addTo(map);
                 
                 // Initial position
                 onMove(initialCenter.lat, initialCenter.lng);
                 
                 draggableMarkerRef.current.on('dragend', (e) => {
                     const { lat, lng } = e.target.getLatLng();
                     onMove(lat, lng);
                 });
                 map.on('click', (e) => {
                    if (draggableMarkerRef.current) {
                        draggableMarkerRef.current.setLatLng(e.latlng);
                        onMove(e.latlng.lat, e.latlng.lng);
                    }
                 });
            }
        }
    }, [isDraggable, onMove, center, zoom, customIcon]);
    
    // This effect runs separately to avoid re-initializing the map on every prop change.
    useEffect(() => {
        const map = mapRef.current;
        if (!map) return;

        // --- Draggable Marker Logic ---
        if (isDraggable && draggableMarkerRef.current && center) {
            const newLatLng = L.latLng(center.lat, center.lng);
            // Only update if the position is meaningfully different to avoid fighting with user drag
            if (!draggableMarkerRef.current.getLatLng().equals(newLatLng, 1e-5)) {
                draggableMarkerRef.current.setLatLng(newLatLng);
            }
            map.setView(newLatLng, map.getZoom());
            return; // Don't run route/static marker logic if in draggable mode
        }

        // --- Static Markers & Route Logic ---
        // Clear previous layers first
        if (fromMarkerRef.current) map.removeLayer(fromMarkerRef.current);
        if (toMarkerRef.current) map.removeLayer(toMarkerRef.current);
        routeLayersRef.current.forEach(layer => map.removeLayer(layer));
        
        fromMarkerRef.current = null;
        toMarkerRef.current = null;
        routeLayersRef.current = [];

        const markers: L.LatLng[] = [];
        
        if (fromLocation) {
            const fromLatLng: L.LatLngTuple = [fromLocation.lat, fromLocation.lng];
            fromMarkerRef.current = L.marker(fromLatLng).addTo(map).bindPopup('Start');
            markers.push(L.latLng(fromLatLng));
        }

        if (toLocation) {
            const toLatLng: L.LatLngTuple = [toLocation.lat, toLocation.lng];
            toMarkerRef.current = L.marker(toLatLng).addTo(map).bindPopup('End');
            markers.push(L.latLng(toLatLng));
        }
        
        if (routeGeometries && routeGeometries.length > 0) {
            const allBounds = new L.FeatureGroup();
            routeGeometries.forEach((geom, index) => {
                const routeLayer = L.geoJSON(geom, {
                    style: () => ({ color: routeColors[index % routeColors.length], weight: 5, opacity: 0.7 })
                }).addTo(map);
                routeLayersRef.current.push(routeLayer);
                allBounds.addLayer(routeLayer);
            });
            
            if(fromMarkerRef.current) allBounds.addLayer(fromMarkerRef.current);
            if(toMarkerRef.current) allBounds.addLayer(toMarkerRef.current);


            const bounds = allBounds.getBounds();
            if (bounds.isValid()) {
                map.fitBounds(bounds, { padding: [25, 25] });
            }
        } else if (markers.length > 0) {
            map.fitBounds(L.latLngBounds(markers), { padding: [50, 50], maxZoom: 14 });
        } else {
             map.setView(center ? [center.lat, center.lng] : defaultPosition, zoom);
        }

    }, [fromLocation, toLocation, routeGeometries, isDraggable, center, zoom]);
    
    // Effect to handle cleanup
    useEffect(() => {
      const mapInstance = mapRef.current;
      return () => {
          mapInstance?.remove();
          mapRef.current = null;
      };
    }, []);
    
  return <div ref={mapContainerRef} style={{ height: '100%', width: '100%', zIndex: 0 }} />;
}
