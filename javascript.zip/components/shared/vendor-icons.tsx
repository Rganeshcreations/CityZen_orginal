
'use client';

import type { VendorName } from '@/lib/types';
import Image from 'next/image';

const vendorLogos: Record<VendorName, { src: string; alt: string }> = {
  Amazon: { src: '/logos/amazon.svg', alt: 'Amazon' },
  Flipkart: { src: '/logos/flipkart.svg', alt: 'Flipkart' },
  Croma: { src: '/logos/croma.svg', alt: 'Croma' },
  'Reliance Digital': { src: '/logos/reliance-digital.svg', alt: 'Reliance Digital' },
  OnePlus: { src: '/logos/oneplus.svg', alt: 'OnePlus' },
  Myntra: { src: '/logos/myntra.svg', alt: 'Myntra' },
  Ajio: { src: '/logos/ajio.svg', alt: 'Ajio' },
  Decathlon: { src: '/logos/decathlon.svg', alt: 'Decathlon' },
};

export function VendorIcon({ vendor }: { vendor: VendorName }) {
  const logo = vendorLogos[vendor];

  if (!logo) {
    return <div className="h-6 w-6 rounded-full bg-muted" />;
  }

  return (
    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-white p-0.5">
      <Image src={logo.src} alt={logo.alt} width={20} height={20} className="object-contain" />
    </div>
  );
}

    