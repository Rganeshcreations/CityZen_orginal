
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { SplashScreen } from '@/app/splash-screen';

export function Redirect({ to }: { to: string }) {
  const router = useRouter();

  useEffect(() => {
    router.push(to);
  }, [router, to]);

  // Render a splash screen while the redirect is in progress.
  return <SplashScreen />;
}
