
'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import type { FirestorePermissionError } from '@/firebase/errors';
import { useToast } from '@/hooks/use-toast';

/**
 * A client-side component that listens for Firestore permission errors
 * and displays them in a toast and the developer console.
 */
export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    const handlePermissionError = (error: FirestorePermissionError) => {
      console.error(
        'Firestore Permission Error Context:',
        JSON.stringify(error.context, null, 2)
      );

      // The toast and throw statements below are commented out to prevent
      // the error from being displayed visibly to the user, as requested.

      // toast({
      //   variant: 'destructive',
      //   title: 'Firestore: Insufficient Permissions',
      //   description: (
      //     <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
      //       <code className="text-white">{JSON.stringify(error.context, null, 2)}</code>
      //     </pre>
      //   ),
      //   duration: 30000, // Keep toast open longer for debugging
      // });

      // We re-throw the error to make it visible in the Next.js development overlay
      // throw error;
    };

    errorEmitter.on('permission-error', handlePermissionError);

    return () => {
      errorEmitter.off('permission-error', handlePermissionError);
    };
  }, [toast]);

  return null;
}
